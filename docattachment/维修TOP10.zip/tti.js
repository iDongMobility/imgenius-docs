﻿/// <create>页面初始化
///   <para></para>
/// </create>
$(document).ready(function () {
    var tti = new TTI();
    // 固定如此
    window.customReportObj = tti;
    window.parent.customReportIndex.SetCustomReportObj(tti);
    tti._bindEvent();
    $(window).on('resize', function () {
        tti._setHeight();
    });
});


//**********javascript class define*****************

/// <summary>构造函数
///   <para></para>
/// </summary>
function TTI() {
    // 固定如此
    this.parentObj = window.parent.customReportIndex;
    this.chart = null;
}



//**********public methods*************************

/// <summary>发起查询
///   <para>函数名固定</para>
/// </summary>
/// <return></returen>
TTI.prototype.Query = function (_conditions) {
    var that = this;
    var conditionObj = {};
    if (_conditions) {
        conditionObj = JSON.parse(_conditions);
        if (conditionObj.OperPanelCondition[0].Items[0].Value == "true")
            $("#TTITableContainer").show();
        else
            $("#TTITableContainer").hide();
    }

    // 向后台发起查询
    that._postToServer("TTIAsset", _conditions, function (_result) {
        var data = [];
        if (_result.IsSuccess) {
            data = _result.Data;
            var _processData = that._processData(data);
            that._drawGraph(_processData);
            that._showTable(data);
            that._setHeight();
        } else {
            that._destory();
            console.log("请求错误：" + _result.Msg);
        }
    });
}

/// <summary>得到状态
///   <para></para>
/// </summary>
TTI.prototype.GetState = function () {
    return "";
}

/// <summary>设置状态
///   <para></para>
/// </summary>
TTI.prototype.SetState = function (_data) {
}

/// <summary>导出
///   <para></para>
/// </summary>
TTI.prototype.Export = function () {
    DataTool.ExportByTable("TTITable", "异常分类表");
}



//**********private methods******************

/// <summary>绑定事件
/// </summary>
TTI.prototype._bindEvent = function () {
    var that = this;
    $(".cbDisplayTable").unbind("click").click(function () {
        if ($('.cbDisplayTable input').prop('checked'))
            $("#TTITableContainer").show();
        else
            $("#TTITableContainer").hide();
    });
}

/// <summary>向后台提交请求
///   <para></para>
/// </summary>
/// <param name="_operateType" type="string">操作类型</param>
/// <param name="_parameter" type="string">查询条件</param>
/// <param name="_callback" type="Function">回调函数</param>
TTI.prototype._postToServer = function (_operateType, _parameter, _callback) {
    this.parentObj.PostToServer(_operateType, _parameter, _callback);
}

/// <summary>处理数据
///   <para></para>
/// </summary>
TTI.prototype._processData = function (data) {
    var that = this;
    var processData = {};
    var _categories = [];
    var _series = [{
        name: '维修等待时长',
        data: [],
        tooltip: {
            valueSuffix: '分钟'
        }
    }, {
        name: '维修员作业时长 + 现场确认时长',
        data: [],
        tooltip: {
            valueSuffix: '分钟'
        }
    }, {
        name: '维修次数',
        data: [],
        yAxis: 2,
        type: 'line',
        tooltip: {
            valueSuffix: '次'
        }
    }];

    data.sort(function (a, b) {
        return (b.WaitTime + b.WorkTime + b.ConfirmTime) - (a.WaitTime + a.WorkTime + a.ConfirmTime);
    });
    for (var i = 0; i < 10 && i < data.length; i++) {
        _categories.push(data[i].Name);
        _series[0].data.push(data[i].WaitTime);
        var WorkTimeConfirmTime = 0;
        var con = data[i].ConfirmTime;
        var work = data[i].WorkTime;
        WorkTimeConfirmTime = (con > 0 ? con : 0) + (work > 0 ? work : 0);
        _series[1].data.push(Math.round(WorkTimeConfirmTime * 100) / 100);
        _series[2].data.push(data[i].Count);
    }
    processData.series = _series;
    processData.categories = _categories;
    return processData;
}

/// <summary>绘制
/// </summary>
TTI.prototype._drawGraph = function (_data) {
    var series = _data.series;
    var _categories = _data.categories;

    var options = {};
    options = this._InitGraphOptions(_categories);
    options.series = series;

    this._destory();
    this.chart = new Highcharts.Chart(options);
}

/// <summary>销毁
/// </summary>
TTI.prototype._destory = function () {
    if (this.chart != null) {
        this.chart.destroy();
        this.chart = null;
    }
}

/// <summary>初始化
///   <para></para>
/// </summary>
TTI.prototype._InitGraphOptions = function (_categories) {
    var _this = this;
    var options = {
        chart: {
            renderTo: document.getElementById("ttiContainer"),
            backgroundColor: '#f9f9f9',
            height: "400px",
            type: 'column'
        },
        credits: { enabled: false },
        exporting: { enabled: false },
        title: {
            text: ''
        },
        xAxis: {
            categories: _categories
        },
        yAxis: [{
            labels: {
                format: '{value}' + '分钟',
                style: {
                    color: Highcharts.getOptions().colors[1]
                }
            },
            title: {
                text: ''
            }
        }, {
            labels: {
                format: '{value}' + "分钟",
                style: {
                    color: Highcharts.getOptions().colors[1]
                }
            },
            title: {
                text: ''
            }
        }, {
            labels: {
                format: '{value}' + "次",
                style: {
                    color: Highcharts.getOptions().colors[1]
                }
            },
            title: {
                text: ''
            },
            opposite: true,
            allowDecimals: false
        }],
        //tooltip: {
        //    shared: true,            
        //},    
        tooltip: {
            formatter: function () {
                return '<b>' + this.x + '</b><br/>' +
                    this.series.name + ': ' + this.y + (this.point.stackTotal ? " 分钟" : " 次") + '<br/>' +
                    (this.point.stackTotal ? ('总维修时间: ' + this.point.stackTotal + " 分钟") : "");
            }
        },
        legend: {
            enabled: true
        },
        plotOptions: {
            column: {
                stacking: 'normal',
            }
        },
        series: []
    };
    return options;
}

/// <summary>设置高度
///   <para></para>
/// </summary>
TTI.prototype._setHeight = function () {
    this.parentObj.SetHeight($('#ttiContainer').height() + $("#TTITableContainer").height() + 100);
}

/// <summary>显示表格
///   <para></para>
/// </summary>
TTI.prototype._showTable = function (_data) {
    var that = this;
    var tableHtmls = [];
    _data = _data.slice(0, 10);
    tableHtmls.push('<div id="table" class="div-table-kpi">');
    if (_data && _data.length > 0) {
        tableHtmls.push('<table border="1" id="TTITable" class="table-kpi" style="word-break:break-all;">');

        // 列
        tableHtmls.push('<thead>');
        tableHtmls.push('<tr class="tr-kpi">');
        tableHtmls.push('<th class="tc"></th>');
        for (var i = 0; i < _data.length; i++) {
            tableHtmls.push('<th class="tc">' + _data[i].Name + '</th>');
        }
        tableHtmls.push('<th class="tc">统计</th>');
        tableHtmls.push('</tr>');
        tableHtmls.push('</thead>');

        // 行
        tableHtmls.push('<tbody');

        tableHtmls.push('<tr>');
        tableHtmls.push('<th class="tc">维修次数</th>');
        var countTotal = 0;
        for (var j = 0; j < _data.length; j++) {
            tableHtmls.push('<td class="tc">' + _data[j].Count + '</td>');
            countTotal += _data[j].Count;
        }
        tableHtmls.push('<td class="tc">' + Math.round(countTotal) + '</td>');
        tableHtmls.push('</tr>');

        tableHtmls.push('<tr>');
        tableHtmls.push('<th class="tc">等待时间</th>');
        var waitTimeTotal = 0;
        for (var j = 0; j < _data.length; j++) {
            var waitTime = _data[j].WaitTime;
            if (waitTime < 0)
                waitTime = 0;
            tableHtmls.push('<td class="tc">' + waitTime + '</td>');
            waitTimeTotal += _data[j].WaitTime;
        }
        tableHtmls.push('<td class="tc">' + Math.round(waitTimeTotal * 100) / 100 + '</td>');
        tableHtmls.push('</tr>');

        tableHtmls.push('<tr>');
        tableHtmls.push('<th class="tc">维修时间</th>');
        var repairTimeTotal = 0;

        for (var j = 0; j < _data.length; j++) {
            var WorkTime = _data[j].WorkTime;
            if (WorkTime < 0)
                WorkTime = 0;
            var ConfirmTime = _data[j].ConfirmTime;
            if (ConfirmTime < 0)
                ConfirmTime = 0;
            var repairTime = WorkTime + ConfirmTime;
            tableHtmls.push('<td class="tc">' + Math.round(repairTime * 100) / 100 + '</td>');
            repairTimeTotal += repairTime;
        }
        tableHtmls.push('<td class="tc">' + Math.round(repairTimeTotal * 100) / 100 + '</td>');
        tableHtmls.push('</tr>');

        tableHtmls.push('<tr>');
        tableHtmls.push('<th class="tc">总维修时间</th>');
        var timeTotal = 0;
        for (var j = 0; j < _data.length; j++) {
            var time = 0;
            var WorkTime = _data[j].WorkTime;
            if (WorkTime < 0)
                WorkTime = 0;
            var ConfirmTime = _data[j].ConfirmTime;
            if (ConfirmTime < 0)
                ConfirmTime = 0;
            var WaitTime = _data[j].WaitTime;
            if (WaitTime < 0)
                WaitTime = 0;
            time = WorkTime + ConfirmTime + WaitTime;
            tableHtmls.push('<td class="tc">' + Math.round(time * 100) / 100 + '</td>');
            timeTotal += time;
        }
        tableHtmls.push('<td class="tc">' + Math.round(timeTotal * 100) / 100 + '</td>');
        tableHtmls.push('</tr>');


        tableHtmls.push('</tbody>');
        tableHtmls.push('</table>');
    }
    tableHtmls.push('</div>');
    $("#TTITableContainer").html(tableHtmls.join(""));
}