﻿/// <create>页面初始化
///   <para></para>
/// </create>
$(document).ready(function () {
    var tti = new TTI();
    // 固定如此
    window.customReportObj = tti;
    window.parent.customReportIndex.SetCustomReportObj(tti);
    tti._bindEvent();
    $(window).on('resize', function () {
        tti._setHeight();
    });
});


//**********javascript class define*****************

/// <summary>构造函数
///   <para></para>
/// </summary>
function TTI() {
    // 固定如此
    this.parentObj = window.parent.customReportIndex;
    this.chart = null;
}



//**********public methods*************************

/// <summary>发起查询
///   <para>函数名固定</para>
/// </summary>
/// <return></returen>
TTI.prototype.Query = function (_conditions) {
    var that = this;
    var conditionObj = {};
    if (_conditions) {
        conditionObj = JSON.parse(_conditions);
        that.SetState(conditionObj.GridState);
        if (conditionObj.OperPanelCondition[0].Items[0].Value == "true")
            $("#TTITableContainer").show();
        else
            $("#TTITableContainer").hide();
    }

    // 向后台发起查询
    that._postToServer("PieQuery", _conditions, function (_result) {
        var data = [];
        if (_result.IsSuccess) {
            data = _result.Data;
            var _processData = that._processData(data);
            that._drawGraph(_processData);
            that._showTable(_processData);
            that._setHeight();
        } else {
            that._destory();
            console.log("请求错误：" + _result.Msg);
        }
    });
}

/// <summary>得到状态
///   <para></para>
/// </summary>
TTI.prototype.GetState = function () {
    return "";
}

/// <summary>设置状态
///   <para></para>
/// </summary>
TTI.prototype.SetState = function (_data) {
}

/// <summary>导出
///   <para></para>
/// </summary>
TTI.prototype.Export = function () {
    DataTool.ExportByTable("TTITable", "零件占比表");
}



//**********private methods******************

/// <summary>绑定事件
/// </summary>
TTI.prototype._bindEvent = function () {
    var that = this;
    $(".cbDisplayTable").unbind("click").click(function () {
        if ($('.cbDisplayTable input').prop('checked'))
            $("#TTITableContainer").show();
        else
            $("#TTITableContainer").hide();
    });
}

/// <summary>向后台提交请求
///   <para></para>
/// </summary>
/// <param name="_operateType" type="string">操作类型</param>
/// <param name="_parameter" type="string">查询条件</param>
/// <param name="_callback" type="Function">回调函数</param>
TTI.prototype._postToServer = function (_operateType, _parameter, _callback) {
    this.parentObj.PostToServer(_operateType, _parameter, _callback);
}

/// <summary>处理数据
///   <para></para>
/// </summary>
TTI.prototype._processData = function (_data) {
    var that = this;
    if (_data && _data.length > 0) {
        var count = 0;
        _.each(_data, function (_item) {
            var cur = parseFloat(_item.Count);
            if (_.isNumber(cur))
                count = count + cur;
            _item.y = _item.Count;
            _item.name = _item.Name;
        });

        if (count > 0) {
            _.each(_data, function (_item) {
                var cur = parseFloat(_item.y)
                if (_.isNumber(cur)) {
                    _item.y = parseFloat(((cur / count) * 100).toFixed(2));
                }
            });
        }
    }
    return _data;
}

/// <summary>绘制
/// </summary>
TTI.prototype._drawGraph = function (_data) {
    var options = {};
    options = this._InitPieOptions();
    options.series[0].data = _data;
    
    this._destory();
    this.chart = new Highcharts.Chart(options);
}

/// <summary>销毁
/// </summary>
TTI.prototype._destory = function () {
    if (this.chart != null) {
        this.chart.destroy();
        this.chart = null;
    }
}

/// <summary>初始化Pie Options
///   <para></para>
/// </summary>
TTI.prototype._InitPieOptions = function () {   
    var _this = this;
    var pieOptions = {
        chart: {
            renderTo: document.getElementById("ttiContainer"),
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            height: "400px"
        },
        title: {
            text: ""
        },
        tooltip: {
            formatter: function () {
                return '<b>' + this.point.name + '</b>: ' + this.y + ' %';
            }
        },
        credits: {
            enabled:false
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    color: '#000000',
                    connectorColor: '#000000',
                    formatter: function () {
                        return '<b>' + this.point.name + '</b>: ' + this.y + ' %';
                    }
                },
                showInLegend: true
            }
        },
        series: [{
            type: 'pie',
            data: [],
            name:""
        }]
    };
    return pieOptions;
}

/// <summary>设置高度
///   <para></para>
/// </summary>
TTI.prototype._setHeight = function () {
    this.parentObj.SetHeight($('#ttiContainer').height() + $("#TTITableContainer").height() + 100);
}

/// <summary>显示表格
///   <para></para>
/// </summary>
TTI.prototype._showTable = function (_data) {
    var that = this;
    var tableHtmls = [];
    tableHtmls.push('<div id="table" class="div-table-kpi">');
    if (_data && _data.length > 0) {
        tableHtmls.push('<table border="1" id="TTITable" class="table-kpi" style="word-break:break-all;">');

        // 列
        tableHtmls.push('<thead>');
        tableHtmls.push('<tr class="tr-kpi">');
        tableHtmls.push('<th class="tc"></th>');
        for (var i = 0; i < _data.length; i++) {            
            tableHtmls.push('<th class="tc">' + _data[i].name + '</th>');
        }
        tableHtmls.push('<th class="tc">统计</th>');
        tableHtmls.push('</tr>');
        tableHtmls.push('</thead>');

        // 行
        tableHtmls.push('<tbody');
        
        tableHtmls.push('<tr>');
        tableHtmls.push('<th class="tc">更换数量</th>');
        var countTotal = 0;
        for (var j = 0; j < _data.length; j++) {
            tableHtmls.push('<td class="tc">' + _data[j].Count + '</td>');
            countTotal += _data[j].Count;
        }
        tableHtmls.push('<td class="tc">' + Math.round(countTotal) + '</td>');
        tableHtmls.push('</tr>');

        tableHtmls.push('<tr>');
        tableHtmls.push('<th class="tc">占比</th>');
        var countTotal = 0;
        for (var j = 0; j < _data.length; j++) {
            tableHtmls.push('<td class="tc">' + _data[j].y + '%</td>');
            countTotal += _data[j].y;
        }
        tableHtmls.push('<td class="tc">' + Math.round(countTotal) + '%</td>');
        tableHtmls.push('</tr>');
        
        tableHtmls.push('</tbody>');
        tableHtmls.push('</table>');
    }
    tableHtmls.push('</div>');
    $("#TTITableContainer").html(tableHtmls.join(""));
}