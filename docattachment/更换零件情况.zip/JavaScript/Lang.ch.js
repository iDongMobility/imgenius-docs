﻿function DateTimePickerExLang(){}
DateTimePickerExLang.Year = "年";
DateTimePickerExLang.Month = "月";
DateTimePickerExLang.W1 = "日";
DateTimePickerExLang.W2 = "一";
DateTimePickerExLang.W3 = "二";
DateTimePickerExLang.W4 = "三";
DateTimePickerExLang.W5 = "四";
DateTimePickerExLang.W6 = "五";
DateTimePickerExLang.W7 = "六";

function PageBarExLang() { }
PageBarExLang.PageSize = "每页记录数";
PageBarExLang.PageCount = "总页数";
PageBarExLang.RecNum = "总记录数";

PageBarExLang.First = "首页";
PageBarExLang.Previous = "上一页";
PageBarExLang.Next = "下一页";
PageBarExLang.Bottom = "最后一页";
PageBarExLang.PreviousGroup = "上一组";
PageBarExLang.NextGroup = "下一组";



