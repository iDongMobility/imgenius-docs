﻿/*------------------------------------------------------------------ 
*  版权所有：上海艾动信息科技有限公司
*  文件名：idong.dataTool.js
*  文件功能描述：数据工具js类文件
//----------------------------------------------------------------*/

//**********javascript class define*****************

/// <summary>数据工具js类
///   <para></para>
/// </summary>
function DataTool() { }



//**********public methods*************************

/// <summary>导出
///   <para></para>
/// </summary>
/// <param name="_data" type="Object">要导出的数据</param>
/// <param name="_fileName" type="String">导出的文件名</param>
DataTool.Export = function (_data, _fileName) {
    try {
        var url = "/DataTool/ExportFile";
        var jsonData = JSON2.stringify(_data);
        jsonData = encodeURIComponent(jsonData);
        var inputs = '<input type="hidden" name="ExportData" value="' + jsonData + '" />';
        inputs += '<input type="hidden" name="FileName" value="' + encodeURIComponent(_fileName) + '" />'
        $('<form action="' + url + '" method="post">' + inputs + '</form>').appendTo('body').submit().remove();
    }
    catch (_e) {
        SysCommon.MessageBox('导出出现错误，原因为：' + _e.message);
    }
}

/// <summary>导出
///   <para></para>
/// </summary>
/// <param name="_tableID" type="String">要导出的html table id</param>
/// <param name="_fileName" type="String">导出的文件名</param>
DataTool.ExportByTable = function (_tableID, _fileName) {
    try {
        var data = this.GetDataByTable(_tableID);
        this.Export(data, _fileName);
    }
    catch (_e) {
        SysCommon.MessageBox('导出出现错误，原因为：' + _e.message);
    }
}



//**********private event methods******************





//**********private process methods****************

/// <summary>通过html table获取数据
///   <para></para>
/// </summary>
/// <param name="_tableID" type="String">html table id</param>
DataTool.GetDataByTable = function (_tableID) {
    var result = new Object();
    result.Columns = [];
    result.Rows = [];

    // 列
    var ths = $('thead', "#" + _tableID).find('tr').find('th');
    for (var i = 0; i < ths.length; i++) {
        if ($(ths[i]).hasClass('colHide'))
            continue;

        var col = new Object();
        col.Title = ths[i].innerText;
        col.Width = $(ths[i]).width();
        result.Columns.push(col);
    }

    // 行    
    if (result.Columns.length > 0) {
        var trs = $('tbody', "#" + _tableID).find('tr');
        for (var i = 0; i < trs.length; i++) {
            var row = new Array();
            var tds = trs[i].cells;
            for (var j = 0; j < tds.length; j++) {
                if ($(tds[j]).hasClass('colHide'))
                    continue;

                var cell = new Object();
                cell.Value = tds[j].innerText;
                if (tds[j].colSpan > 1)
                    cell.ColSpan = tds[j].colSpan
                if (tds[j].rowSpan > 1)
                    cell.RowSpan = tds[j].rowSpan

                row.push(cell);
            }
            result.Rows.push(row);
        }
    }

    return result;
}