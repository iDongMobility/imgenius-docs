/*------------------------------------------------------------------ 
*  ��Ȩ���У��Ϻ�������Ϣ�Ƽ����޹�˾
*  �ļ�����jquery.tooltip.js
*  �ļ�����������jquery tooltip plugin
//----------------------------------------------------------------*/

(function ($) {
    jQuery.fn.tooltip = function (options) {
        var defaults = {
            offsetX: 10,  //X Offset value
            offsetY: 10,  //Y Offset value
            fadeIn: '0', //Tooltip fadeIn speed, can use, slow, fast, number
            fadeOut: '0', //Tooltip fadeOut speed, can use, slow, fast, number
            dataAttr: 'data', //Used when we create seprate div to hold your tooltip data, so plugin search div tage by using id 'data' and current href id on whome the mouse pointer is so if your href id is '_tooltip_1' then the div which hold that tooltips content should have id 'data_tooltip_1', if you change dataAttr from default then you need to build div tag with id 'current dataAttr _tooltip_1' without space
            bordercolor: '#cdcdcd', // tooltip border color
            bgcolor: '#e6e6e6', //Tooltip background color
            fontcolor: '#000', //Tooltip Font color
            fontsize: '12px', // Tooltip font size
            folderurl: 'NULL', // Folder url, where the tooltip's content file is placed, needed with forward slash in the last (/), or can be use as http://www.youwebsitename.com/foldername/ also.
            filetype: 'txt', // tooltip's content files type, can be use html, txt
            height: 'auto', // Tooltip's width
            width: 'auto', //Tooltip's Height
            cursor: '' // Mouse cursor
        };
        var options = $.extend(defaults, options);
        //Runtime div building to hold tooltip data, and make it hidden
        var $tooltip = $('<div id="divToolTip" style="min-width: 150px;z-index:999999"></div>');

        return this.each(function () {
            $('body').append($tooltip);
            $tooltip.hide();
            //Runtime variable definations
            var element = this;
            var id = $(element).attr('id');
            var filename = options.folderurl + id + '.' + options.filetype;
            var dialog_id = '#divToolTip';
            //Tooltips main function
            $(this).hover(function (e) {

                this._GetTop = function (yPos, height) {
                    var top = yPos + options.offsetY;
                    if ($(document).height() < (top + height)) {
                        top = yPos - options.offsetY - height;
                    }
                    if (top < 0)
                        top = 0;
                    return top;
                };

                this._GetLeft = function (xPos, width) {
                    var left = xPos + options.offsetX;
                    if ($(document).width() < (left + width)) {
                        left = xPos - options.offsetX - width;
                    }
                    if (left < 0)
                        left = 0;
                    return left;
                }

                //to check whether the tooltips content files folder is defined or not
                if (options.folderurl != "NULL") {
                    $(dialog_id).load(filename);

                } else {
                    if ($('#' + options.dataAttr + '_' + id).length > 0) {
                        $(dialog_id).html($('#' + options.dataAttr + '_' + id).html());
                        //$(dialog_id).html(size);
                    } else {
                        var tooltipText = $(this).attr("tooltip");
                        if (tooltipText != null && tooltipText != undefined) {
                            if (tooltipText == "")
                                return;
                            else
                                $(dialog_id).html(tooltipText);
                            //$(dialog_id).html(size);
                        }
                        else {
                            var imgSrc = $(this).attr("src");
                            if (imgSrc != null && imgSrc != undefined) {
                                $(dialog_id).html('<img src="' + imgSrc + '" alt="" />');
                            }
                        }
                    }
                }
                //assign css value to div
                $(element).css({ 'cursor': options.cursor });
                $(dialog_id).css({
                    'position': 'absolute',
                    'border': '1px solid ' + options.bordercolor,
                    'background-color': options.bgcolor,
                    'padding': '5px 5px 5px 5px',
                    '-moz-border-radius': '5px 5px 5px 5px',
                    '-webkit-border-radius': '5px 5px 5px 5px',
                    'top': this._GetTop(e.pageY, $(dialog_id).height()),
                    'left': this._GetLeft(e.pageX, $(dialog_id).width()),
                    'color': options.fontcolor,
                    'font-size': options.fontsize,
                    'font-family': "΢���ź�",
                    'height': options.height,
                    'width': options.width
                });
                //enable div block
                $(dialog_id).stop(true, true).fadeIn(options.fadeIn);
            }, function () {
                // when mouse out remove all data from div and make it hidden
                $(dialog_id).stop(true, true).fadeOut(options.fadeOut);
            }).mousemove(function (e) {

                this._GetTop = function (yPos, height) {
                    var top = yPos + options.offsetY;
                    if ($(document).height() < (top + height)) {
                        top = yPos - options.offsetY - height;
                    }
                    if (top < 0)
                        top = 0;
                    return top;
                };

                this._GetLeft = function (xPos, width) {
                    var left = xPos + options.offsetX;
                    if ($(document).width() < (left + width)) {
                        left = xPos - options.offsetX - width;
                    }
                    if (left < 0)
                        left = 0;
                    return left;
                }
                // to make tooltip moveable with mouse	
                $(dialog_id).css({
                    'top': this._GetTop(e.pageY, $(dialog_id).height()),
                    'left': this._GetLeft(e.pageX, $(dialog_id).width()),
                    'height': options.height,
                    'width': options.width
                });
            });
        });
    };
})(jQuery);