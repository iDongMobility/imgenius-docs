﻿//*************************************************
//               init code                        *
//*************************************************

var dateTimePickerManager;
var curCmbDateType = "" //当前下拉框数据类型
var curRowTime; //当前时间对象
$(function () {
    dateTimePickerManager = new DateTimePickerManager();
});

// <summary>
// 日期时间控件管理
// </summary>
function DateTimePickerManager() {
}
// <summary>
// 日期时间控件管理:原型
// </summary>
DateTimePickerManager.prototype = {
    //获取复合日期时间控件Html
    GetComplexDateTime: function (_curCmbDateType, condtion, curIndex) {
        var selectInnerHtml = "";
        var curDateVal = "";
        if (IsNotNull(condtion) && IsNotNull(condtion.Value)) {
            curDateVal = condtion.Value.split(' ');
        }
        if (IsNotNull(curDateVal)) {
            selectInnerHtml = "<input class='datetime validate[custom[relativedate]]'  type='text' style='height:15px;width:90px;margin-top:0px;background-color:#FFFFFF;'   id='value" + curIndex + "'  value='" + curDateVal[0] + "' onclick=''  />";
        }
        else {
            selectInnerHtml = "<input class='datetime validate[custom[relativedate]]'  type='text' style='height:15px;width:90px;margin-top:0px;background-color:#FFFFFF;'   id='value" + curIndex + "'  value='" + curDateVal + "' onclick=''  />";
        }
        selectInnerHtml += "<span class='pl5' id='spanTxtTime" + curIndex + "' ></span>";
        lastDatetimeID = "value" + curIndex;
        return selectInnerHtml;
    },
    // <summary>
    // 获取时间
    // </summary>
    GetTxtTime: function (cmbType, curRowId) {
        if (IsNotNull(cmbType) && cmbType == "DateTime") {
            var objTime = new Object();
            objTime.ContainerId = "spanTxtTime" + curRowId;
            objTime.Format = "HH:mm:ss";
            objTime.IsShowCheckBox = true;
            objTime.IsShowButton = false;
            objTime.Checked = false;
            curRowTime = WebFace.CreateDateTimePickerEx(objTime);
            $("#" + objTime.ContainerId).data("timeObj", curRowTime);
        }
    },
    // <summary>
    // 编辑加载日期时间
    // </summary>
    EditShowDateTime: function (item, curRowId, condtion) {
        if (IsNotNull(item) && IsNotNull(item.title) && item.title == "DateTime") {
            var objTime = new Object();
            objTime.ContainerId = "spanTxtTime" + curRowId;
            objTime.Format = "HH:mm:ss";
            objTime.IsShowButton = false;
            objTime.IsShowCheckBox = true;
            if (IsNotNull(condtion) && IsNotNull(condtion.Value)) {
                var _dt = condtion.Value.split(' ');
                if (IsNotNull(_dt[1])) {
                    curRowTime = WebFace.CreateDateTimePickerEx(objTime);
                    curRowTime.SetValue(_dt[1], "HH:mm:ss");
                    curRowTime.SetCheckBoxValue(true);
                    $("#" + objTime.ContainerId).data("timeObj", curRowTime);
                }
                else {
                    curRowTime = WebFace.CreateDateTimePickerEx(objTime);
                    curRowTime.SetCheckBoxValue(false);
                    $("#" + objTime.ContainerId).data("timeObj", curRowTime);
                }
            }
            else {
                curRowTime = WebFace.CreateDateTimePickerEx(objTime);
                curRowTime.SetCheckBoxValue(false);
                $("#" + objTime.ContainerId).data("timeObj", curRowTime);
            }
        }
    },

    // <summary>
    // 绑定日期控件事件
    // </summary>
    ///<para name ="className">类名称</para>
    BindDateTimeEvent: function (className) {
        if (!Commons.IsNotNull(className)) {
            className = ".datetime";
        }
        $('.calpick').remove();
        $(className).datepicker({ picker: "<input class='calpick' type='button' style='margin-left: 5px; margin-bottom: 4px;'/>" });
    },

    // <summary>绑定日期控件事件
    // 
    // </summary>
    ///<para name ="_containerJObj">容器JQuery Object</para>
    BindDateEvent: function (_containerJObj) {
        $('.calpick', _containerJObj).remove();
        $('.datetime', _containerJObj).datepicker({ picker: "<input class='calpick' type='button' style='margin-left: 5px; margin-bottom: 4px;'/>" });
    },

    // <summary>
    // 日期控件设置相对时间
    // </summary>
    ///<para name ="selectId">元素ID</para>
    SetRelativeTime: function (selectId) {
        var arrT = [];
        arrT.push({ text: "今天" });
        arrT.push({ text: "本周初" });
        arrT.push({ text: "本周末" });
        arrT.push({ text: "本月初" });
        arrT.push({ text: "本月末" });
        arrT.push({ text: "本季初" });
        arrT.push({ text: "本季末" });
        $(selectId).dropdown({
            dropheight: 140,
            dropwidth: 80,
            selectedchange: function () { },
            items: arrT
        });
    },
    // <summary>
    // 设置时间
    // </summary>
    ///<para name ="_containerId">容器ID</para>
    ///<para name ="_timeValue">时间值</para>
    ///<para name ="isCheck">是否选中时间复选框</para>
    ///<para name ="_format">时间格式化</para>
    ///<para name ="_isShowCheckBox">是否显示时间复选框</para>
    ///<para name ="_valueChanged">数据改变事件</para>
    SetTime: function (_containerId, _timeValue, isCheck, _format, _isShowCheckBox, _valueChanged) {
        var time = new Object();
        time.ContainerId = _containerId;
        time.Format = _format;
        time.IsShowCheckBox = _isShowCheckBox;
        time.IsShowButton = false;
        time.ValueChanged = _valueChanged;
        time = WebFace.CreateDateTimePickerEx(time);
        time.SetValue(_timeValue, time.Format);
        if (isCheck) {
            time.SetCheckBoxValue(true);
        }
        else {
            time.SetCheckBoxValue(false);
        }
        //缓存时间对象，以便保存时使用
        $("#" + _containerId).data("timeBuffer", time);
    }
}
