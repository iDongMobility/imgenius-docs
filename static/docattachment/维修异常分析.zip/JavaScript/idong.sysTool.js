﻿//*********WebConfig Class******************

function WebConfig() { }

WebConfig.RsCtrlsUrl = "/Content/WebControls";



//************系统工具类********************

function SysTool() { }

/// <summary>显示等待消息
///   <para></para>
/// </summary>
SysTool.ShowMessage = function (_message, _top, _left, _width, _height, _offsetX, _offsetY, _isShowBorder) {
    _width = !_width? 200 : _width;
    _height = !_height? 27 : _height;
    _offsetX = !_offsetX? 0 : _offsetX;
    _offsetY = !_offsetY? 0 : _offsetY;
   
    WebFace.ShowMessage( "正在加载数据，请稍候 ........................", null, null, _width, _height, _offsetX, _offsetY);
}

/// <summary>隐藏等待消息
///   <para></para>
/// </summary>
SysTool.HideMessage = function () { WebFace.HideMessage() };

/// <summary>系统对话框
///   <para></para>
/// </summary>
SysTool.ShowDialog = function (_pageUrl, _title, _ox, _oy, _width, _height, _tag, _winStyle, _iconStyle, _waitBarStyle) {
    //show dialog
    var _config = new Object();
    _config.Title = _title;
    _config.OX = _ox;
    _config.OY = _oy;
    _config.Width = _width;
    _config.Height = _height;
    _config.Tag = _tag;
    _config.Style = _winStyle || "GrayFlat";
    _config.TitleIcon = _iconStyle;
    _config.WaitBarStyle = _waitBarStyle;
    _config.PageUrl = _pageUrl;
   
    return WebFace.ShowDialog(_config);
}

/// <summary>取得对话框的父窗体的相关参数
///   <para></para>
/// </summary>
SysTool.GetDialogArguments = function () {
    return WebFace.GetDialogArguments();
}

/// <summary>取得对话框的父窗体的相关参数
///   <para></para>
/// </summary>
SysTool.GetDialogTag = function () {
    return WebFace.GetDialogArguments().Arguments.Parameters;
}

/// <summary>为对象添加事件
///   <para></para>
/// </summary>
SysTool.AddEvent = function (_sender, _eventName, _fun) {
    if (_sender.attachEvent) {
        _sender.attachEvent(_eventName, _fun, true);
    }
    else {
        _sender.addEventListener(_eventName, _fun, true);
    }
}

/// <summary>取得指定事件对象的坐标
///   <para></para>
/// </summary>
SysTool.GetEventCoords = function (_doc, _evt, _isCalculateOffset) {
    return WebFace.GetEventCoords(_doc, _evt, _isCalculateOffset);
}

/// <summary>将对象序列化
///   <para></para>
/// </summary>
SysTool.Json = function (_objData) {
    return WebFace.JSON(_objData);
}

/// <summary>将对象反序列化
///   <para></para>
/// </summary>
SysTool.CreateObject = function (_jsonData) {
    return WebFace.CreateObject(_jsonData);
}

/// <summary>取得时间数字
///   <para></para>
/// </summary>
SysTool.GetTimeNumbers = function () {
    var _date = new Date();
    return "" + _date.getFullYear() + _date.getMonth() + _date.getDate() + _date.getHours() + _date.getMinutes() + _date.getSeconds() + _date.getMilliseconds();
}

/// <summary>输出调试信息
///   <para></para>
/// </summary>
/// <param name="_msg" type="string">信息内容</param>
SysTool.LogInfo = function (_msg) {
    if (window.console)
        window.console.info(_msg);
}

/// <summary>输出警告调试信息
///   <para></para>
/// </summary>
/// <param name="_msg" type="string">信息内容</param>
SysTool.LogWarn = function (_msg) {
    if (window.console)
        window.console.warn(_msg);
}

/// <summary>输出错误调试信息
///   <para></para>
/// </summary>
/// <param name="_msg" type="string">信息内容</param>
SysTool.LogError = function (_msg) {
    if (window.console)
        window.console.error(_msg);
}

/// <summary>输出对象所有方法和属性
///   <para></para>
/// </summary>
/// <param name="_obj" type="object">对象</param>
SysTool.LogDir = function (_obj) {
    if (window.console)
        window.console.dir(_obj);
}

/// <summary>输出html元素的xml树
///   <para></para>
/// </summary>
/// <param name="_html" type="object">html元素</param>
SysTool.LogDirXml = function (_html) {
    if (window.console)
        window.console.dirxml(_html);
}



//******function extend*************

/// <summary>window extend
///   <para></para>
/// </summary>
window.LoadCallback = function () {
    try {
        var _arguments = SysTool.GetDialogArguments();
        _arguments.LoadCallback();

        var _parentObject = null;
        if (window.frameElement != null) {
            _parentObject = _arguments.Arguments;
            if (_parentObject != null && _parentObject.ChildPageLoadedCallback != null) {
                _parentObject.ChildPageLoadedCallback("PageBase", "load", null);
            }
        };
    }
    catch (e)
    { }
};

/// <summary>array extend
///   <para></para>
/// </summary>
Array.Copy = function (_soruceArray, _targetArray) {
    var _array = _targetArray || new Array();
    _array.length = 0;
    for (var i = 0; i < _soruceArray.length; i++) {
        _array.push(_soruceArray[i]);
    };
    return _array;
};

/// <summary>funtcion extend
///   <para></para>
/// </summary>
Function.prototype.Inherit = function (_childClass, _baseClass) {
    for (var _baseProperty in _baseClass.prototype) {
        var _isOverride = false; for (var _childProperty in _childClass) {
            if (_baseProperty == _childProperty) { _isOverride = true; break; }
        }
        if (!_isOverride) { this.prototype[_baseProperty] = _baseClass.prototype[_baseProperty]; }
    }
    var _objBase = new _baseClass(); for (var _baseProperty in _objBase) {
        var _isOverride = false;
        for (var _childProperty in _childClass) {
            if (_baseProperty == _childProperty)
            { _isOverride = true; break; }
        }
        if (!_isOverride) { _childClass[_baseProperty] = _objBase[_baseProperty]; }
    }
}