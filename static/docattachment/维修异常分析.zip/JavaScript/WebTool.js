﻿//*****************************************************
//        public  WebTool class                       *
//*****************************************************
function WebTool() { };

WebTool.ShowMessage = function (_prompt, _t, _l, _w, _h, _oy, _ox, _isShowBorder, _css) {
    //get parameters
    if (_prompt == undefined) _prompt = "";
    _w = !_w ? 200 : _w;
    _h = !_h ? 27 : _h;
    _oy = !_oy ? 0 : _oy;
    _ox = !_ox ? 0 : _ox;

    //get left
    var _area = CoreTool.GetClientAreaParameters(document);
    if (!_l) { _l = _area.ScrollLeft + (_area.Width - _w) / 2; _l -= _ox };
    if (!_t) { _t = _area.ScrollTop + (_area.Height - _h) / 2 - 30; _t -= _oy };

    //get id
    var _id = "sys_wait_banner_webcontrols";

    //create table
    var _tb = document.getElementById(_id);
    var _tr, _td1, _td2, _img;
    if (!_tb) {
        _tb = document.createElement("TABLE");
        _tb.tr = _tr = _tb.insertRow(-1);
        _tb.td1 = _td1 = _tr.insertCell(-1);
        _tb.td2 = _td2 = _tr.insertCell(-1);

        _tb.img = _img = document.createElement("DIV");
        _td1.appendChild(_img);

        document.body.appendChild(_tb);
    }
    else {
        _tr = _tb.tr;
        _td1 = _tb.td1;
        _td2 = _tb.td2;
        _img = _tb.img;
    }

    //set icon td
    _td1.className = "iconTd";
    if (!_css) {
        if (!_prompt) { _td1.style.paddingLeft = "15px"; _td1.style.width = "20px"; };
        _img.className = _prompt ? "img loading3" : "img loading2";
    } else {
        _td1.className = "iconTd";
        _img.className = "img " + _css;
    }

    //create text td
    _td2.className = "txtTd";
    _td2.style.display = !_prompt ? "none" : "";
    _td2.innerHTML = _prompt;

    //set tb
    _tb.id = _id;
    _tb.className = "waitBar_tb" + (!_prompt && !_isShowBorder ? " waitBar_tbBorder" : "");
    _tb.setAttribute("border", "0");
    _tb.setAttribute("cellpadding", "0");
    _tb.style.top = _t + "px";
    _tb.style.left = _l + "px";
    _tb.style.width = _w + "px";
    _tb.style.height = _h + "px";
    _tb.style.display = "block";
    document.body.style.cursor = "wait";

    //create mask
    CoreTool.MaskArea(_id, _t, _l, _w, _h, null, null, true);
};

WebTool.HideMessage = function () {
    try {
        var _id = "sys_wait_banner_webcontrols";

        var _tb = document.getElementById(_id);
        var _twin = CoreTool.GetTopWin();
        if (_tb) {
            _tb.style.display = "none";
            document.getElementById(_id + "_frame_mask").style.display = "none";
            document.getElementById("maskFace").style.display = "none";
        }
    }
    catch (e) { };

    try {
        document.body.style.cursor = "default";
        document.body.focus();
    } catch (e) { }
};


//*****************************************************
//      public dialog tool class                      *
//*****************************************************
function DialogTool() { };
DialogTool.Show = function (_cfg) {
    try {
        if (_cfg.PageUrl) {
            var _idx = _cfg.PageUrl.indexOf("/");

            if (_idx != 0) {
                var _idx = document.location.pathname.lastIndexOf("/");
                if (_idx != 0) {
                    var _path = document.location.pathname.substring(0, _idx);
                    _cfg.PageUrl = _path + "/" + _cfg.PageUrl;
                }
            }
        }
    }
    catch (e) { };
    return new WindowEx(_cfg).Show();
};

DialogTool.GetTag = function () {
    if (!window.frameElement) return null;
    return window.frameElement.Tag || null
};

DialogTool.LoadCallback = function (_objData) {
    if (window.frameElement) {
        if (window.frameElement.LoadCallback) { window.frameElement.LoadCallback(); };
        var _jc = DialogTool.GetTag();
        if (_jc && _jc.ChildPageLoadedCallback) { _jc.ChildPageLoadedCallback(_objData); }
    }
};
DialogTool.Save = function (_objData, _tag) {
    var _jc = DialogTool.GetTag();
    if (window.frameElement) window.setTimeout(window.frameElement.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.CloseWindow, 100);
    if (_jc && _jc.SetReturnValue) _jc.SetReturnValue(_objData, _tag);
};
DialogTool.Close = function () {
    if (window.frameElement) window.frameElement.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.CloseWindow();
};


//*****************************************************
//      public CoreTool class                         *
//*****************************************************
function CoreTool() { };

CoreTool.GetTopWin = function (_popupMode) {
    if (_popupMode == "dropdown") return window;
    return !WebConfig.TopWindow ? window.top : WebConfig.TopWindow;
};

CoreTool.GetEventCoords = function (_doc, _evt, _isCalculateOffset) {
    var _ox = _evt.offsetX || 0;
    var _oy = _evt.offsetY || 0;

    var _x = _evt.clientX || _evt.layerX;
    var _y = _evt.clientY || _evt.layerY;

    var _sender = _evt.currentTarget;
    if (_sender && _sender.x && _ox == 0) {
        if (_sender.x) {
            _ox = _x - _sender.x;
            _oy = _y - _sender.y;
        }
        else {
            _ox = _evt.layerX;
            _oy = _evt.layerY;
        }
    }

    var _bd = _doc.documentElement || _doc.body;
    var _pos = new Object();
    _pos.X = (_bd.scrollLeft || _doc.body.scrollLeft) + _x - _bd.clientLeft;
    _pos.Y = (_bd.scrollTop || _doc.body.scrollTop) + _y - _bd.clientTop;

    if (_isCalculateOffset) {
        _pos.X += 19 - _ox;
        _pos.Y += 17 - _oy;
    }
    _pos.OX = _ox;
    _pos.OY = _oy;

    return _pos;
};

CoreTool.GetDocAreaParameters = function (_doc) {
    var _w1 = 0;
    var _h1 = 0;
    if (_doc.documentElement) {
        var _bd = _doc.documentElement;

        _w1 = CoreTool.GetMaxValue(_bd.clientWidth, _bd.offsetWidth, _bd.scrollWidth);
        _h1 = CoreTool.GetMaxValue(_bd.clientHeight, _bd.offsetHeight, _bd.scrollHeight);
    };

    var _w2 = 0;
    var _h2 = 0;
    var _bd = _doc.body;
    _w1 = CoreTool.GetMaxValue(_bd.clientWidth, _bd.offsetWidth, _bd.scrollWidth);
    _h1 = CoreTool.GetMaxValue(_bd.clientHeight, _bd.offsetHeight, _bd.scrollHeight);

    var _w = CoreTool.GetMaxValue(_w1, _w2);
    var _h = CoreTool.GetMaxValue(_h1, _h2);

    if (CoreTool.IsExistScrollV(_doc)) _w = _w;
    var _para = new Object();
    _para.Width = _w;
    _para.Height = _h;
    return _para;
};

CoreTool.GetClientAreaParameters = function (_doc) {
    var _bd = _doc.documentElement;
    var _para = new Object();
    _para.ScrollLeft = CoreTool.GetMaxValue(_doc.body.scrollLeft, _bd.scrollLeft);
    _para.ScrollTop = CoreTool.GetMaxValue(_doc.body.scrollTop, _bd.scrollTop);

    var _w1 = _doc.body ? _doc.body.clientWidth : 0;
    var _w2 = _bd ? _bd.clientWidth : 0;
    var _w = 0;
    if (!CoreTool.IsExistScrollH(_doc)) {
        _w = (_w1 > _w2) ? _w1 : _w2;
        if (CoreTool.IsExistScrollV(_doc)) _w = _w;
    }
    else {
        _w = (_w1 > _w2 && _w2 != 0) || _w1 == 0 ? _w2 : _w1;
    };
    _para.Width = _w;

    var _h1 = _doc.body ? _doc.body.clientHeight : 0;
    var _h2 = _bd ? _bd.clientHeight : 0;
    var _h = 0;
    if (!CoreTool.IsExistScrollV(_doc)) {
        _h = (_h1 > _h2) ? _h1 : _h2;
    }
    else {
        _h = (_h1 > _h2 && _h2 != 0) || _h1 == 0 ? _h2 : _h1;
    };
    _para.Height = _h;

    return _para;
};

CoreTool.IsExistScrollV = function (_doc) {
    var _isScroll = false;
    var _bd = _doc.documentElement;
    if (_doc.offsetTop > 0 || _bd.offsetTop > 0) {
        _isScroll = true;
    }
    else {
        if (_bd.scrollHeight > 0 && _bd.clientHeight > 0 && _bd.scrollHeight < _bd.clientHeight) {
            _isScroll = false;
        }
        else {
            if (_bd && _bd.clientHeight != 0 && _bd.scrollHeight > _bd.clientHeight) _isScroll = true;
            if (!_isScroll && _doc.body && _doc.body.clientHeight != 0 && _doc.body.scrollHeight > _doc.body.clientHeight) _isScroll = true;
        }
    };
    return _isScroll;
};

CoreTool.IsExistScrollH = function (_doc) {
    var _isScroll = false;
    var _bd = _doc.documentElement;
    if (_doc.offsetLeft > 0 || _bd.offsetLeft > 0) {
        _isScroll = true;
    }
    else {
        if (_bd.scrollWidth > 0 && _bd.clientWidth > 0 && _bd.scrollWidth < _bd.clientWidth) {
            _isScroll = false;
        }
        else {
            if (_bd && _bd.clientWidth != 0 && _bd.scrollWidth > _bd.clientWidth) _isScroll = true;
            if (!_isScroll && _doc.body && _doc.body.clientWidth != 0 && _doc.body.scrollWidth > _doc.body.clientWidth) _isScroll = true;
        }
    };
    return _isScroll;
};

CoreTool.IsIE = function () { return window.navigator.appName.toLowerCase().indexOf('internet explorer') >= 0 ? true : false };

CoreTool.MaskArea = function (_id, _t, _l, _w, _h, _zIndex, _clickHandler, _isMaskTop) {
    //create mask face
    if (_isMaskTop != false) {
        if (!_isMaskTop) { CoreTool.MaskFace(CoreTool.GetTopWin(), _clickHandler); }
        CoreTool.MaskFace(window, _clickHandler);
    }
    else {
        document.body.onclick = _clickHandler;
    }

    //mask element
    var _doc = document;
    var _imask = document.getElementById(_id + "_frame_mask");

    if (!_imask) {
        _imask = document.createElement("DIV");
        _imask.style.display = "none";
        _doc.body.appendChild(_imask);
    };

    _imask.style.zIndex = _zIndex ? _zIndex : 99999998;
    _imask.id = _id + "_frame_mask";
    _imask.style.top = _t + "px";
    _imask.style.left = _l + "px";
    _imask.style.width = _w + "px";
    _imask.style.height = _h + "px";
    _imask.style.position = "absolute"
    _imask.setAttribute("frameBorder", "0");
    _imask.scrolling = "no";
    _imask.style.opacity = ".0";
    _imask.style.filter = "alpha(opacity=0)";
    _imask.style.display = "block";

    return _imask;
};

CoreTool.MaskFace = function (_win, _clickHandler) {
    //get document,window
    var _maskName = "maskFace";
    var _doc = _win.document;
    var _docArea = CoreTool.GetDocAreaParameters(_doc);

    //create mask
    var _dmask = _doc.getElementById(_maskName);
    if (!_dmask) {
        _dmask = _doc.createElement("DIV");
        _dmask.id = _maskName;
        _dmask.style.display = "none";
        _doc.body.appendChild(_dmask);
    };

    _dmask.style.backgroundColor = "#f0f0f0";
    _dmask.style.zIndex = "99999997";
    _dmask.style.position = "absolute";
    _dmask.style.opacity = ".1";
    _dmask.style.filter = "alpha(opacity=10)";
    _dmask.style.top = "0px";
    _dmask.style.left = "0px";
    _dmask.style.width = _docArea.Width - 5 + "px";
    _dmask.style.height = _docArea.Height - 5 + "px";
    _dmask.style.display = "block";
    if (_clickHandler) _dmask.onclick = _clickHandler;
};

CoreTool.AddEvent = function (_sender, _eventName, _handler) {
    if (window.addEventListener) { _eventName = _eventName.substring(2); _sender.addEventListener(_eventName, _handler, true); }
    else { _sender.attachEvent(_eventName, _handler, true); }
};

CoreTool.RemoveEvent = function (_sender, _eventName, _handler) {
    if (window.addEventListener) { _eventName = _eventName.substring(2); _sender.removeEventListener(_eventName, _handler, true); }
    else { _sender.detachEvent(_eventName, _handler, true); }
};

CoreTool.IsNumeric = function (_str) {
    for (var i = 0; i < _str.length; i++) {
        var _ch = _str[i];
        if (_ch < '0' || _ch > '9') return false;
    }

    return true;
};

CoreTool.FormatCode = function (_val, _length) {
    var _code = _val.toString();

    var _count = _length - _code.length;
    for (var i = 0; i < _count; i++) {
        _code = "0" + _code;
    }

    return _code;
};

CoreTool.TrimZero = function (_val) {
    var _isZero = true;
    var _rs = "";
    var _arr = _val.split("");
    for (var i = 0; i < _arr.length; i++) {
        if (!(_isZero && _arr[i] == "0")) {
            _rs += _arr[i];
            _isZero = false;
        }
    }
    return _rs == "" ? _val : _rs;
};

CoreTool.IsInCss = function (_e, _class) {
    if (_e) {
        while ((_e = _e.parentNode)) {
            if (_e.className && _e.className.indexOf(_class) >= 0) return true;
        }
    }

    return false;
};

CoreTool.GetMaxValue = function (_v1, _v2, _v3) {
    var _max = _v1 || _v2 || _v3 || 0;
    _max = _v2 && _v2 > _max ? _v2 : _max;
    _max = _v3 && _v3 > _max ? _v3 : _max;
    return _max;
};

CoreTool.CreateEelement = function (_tag, _css, _html, _cc) {
    var _doc = document;
    var _e = _doc.createElement(_tag);
    _e.className = _css ? _css : "";
    _e.innerHTML = _html ? _html : "";
    _cc.appendChild(_e);
    return _e;
}

CoreTool.CreateTable = function (_doc, _css, _cc) {
    var _tb = _doc.createElement("TABLE");
    _tb.setAttribute("border", "0");
    _tb.setAttribute("cellPadding", "0");
    _tb.setAttribute("cellSpacing", "0");
    _tb.className = _css;
    if (_cc) _cc.appendChild(_tb);
    return _tb;
};

CoreTool.CreateTr = function (_tb, _css) {
    var _tr = _tb.insertRow(-1);
    _tr.className = _css;
    return _tr;
};

CoreTool.CreateTd = function (_tr, _css, _html) {
    var _td = _tr.insertCell(-1);
    _td.className = _css;
    if (_html) _td.innerHTML = _html;
    return _td;
};

CoreTool.StopBubble = function (e) {
    if (!e) return;
    if (e && e.stopPropagation) {
        e.preventDefault();
        e.stopPropagation();
    }
    else {
        e.returnValue = false
        e.cancelBubble = true;
    }
}


//*****************************************************
//      public table class                            *
//*****************************************************
function TableTool() { };
TableTool.ConvertToLineNodes = function (_dt, _idColName, _pidColName, _rootValue, _sortColName, _sortType, _rootNode) {
    TableTool.Sort(_dt, _sortColName, _sortType);
    var _nodes = TableTool.ConvertToTreeNodes(_dt, _idColName, _pidColName, _rootValue);

    if (_rootNode) {
        for (var i = 0; i < _nodes.length; i++) {
            if (!_nodes[i].ParentNode) {
                _nodes[i].ParentNode = _rootNode;
            }
        }
    }

    return TableTool.ConvertTreeNodesToList(_nodes);
};

TableTool.ConvertToTreeNodes = function (_dt, _idColName, _pidColName, _parentValue) {
    //create assist hash
    var _hash = new Object();
    for (var i = 0; i < _dt.length; i++) {
        var _row = _dt[i];

        var _node = new Object();
        _node.Row = _row;
        _node.ParentNode = null;
        _node.Nodes = new Array();

        _hash["A" + _row[_idColName]] = _node;
    };

    //create root node
    var _nodes = new Array();

    for (var i = 0; i < _dt.length; i++) {
        var _row = _dt[i];
        var _primaryKey = "A" + _row[_idColName];
        var _parentKey = "A" + _row[_pidColName];

        if (!_hash[_parentKey]) {
            if (_row[_pidColName] == _parentValue || !_parentValue) {
                _nodes.push(_hash[_primaryKey]);
                _hash[_primaryKey].ParentNode = null;
            }
        }
        else {
            if (_row[_pidColName] == _parentValue) {
                _nodes.push(_hash[_primaryKey]);
                _hash[_primaryKey].ParentNode = null;
            }
            else {
                _hash[_parentKey].Nodes.push(_hash[_primaryKey]);
                _hash[_primaryKey].ParentNode = _hash[_parentKey];
            }
        }
    };

    //return
    return _nodes;
};

TableTool.ConvertTreeNodesToList = function (_nodes, _dt) {
    if (_dt == null) _dt = new Array();

    for (var i = 0; i < _nodes.length; i++) {
        var _node = _nodes[i];
        _dt.push(_node);
        if (_node.Nodes.length > 0) {
            TableTool.ConvertTreeNodesToList(_node.Nodes, _dt);
        }
    }

    return _dt;
};

TableTool.Sort = function (_dt, _colName, _sortType) {
    if (!_colName) return _dt;

    for (var i = 0; i < _dt.length - 1; i++) {
        for (var j = i + 1; j < _dt.length; j++) {
            if (_sortType == "desc") {
                if (_dt[j][_colName] > _dt[i][_colName]) {
                    _row = _dt[i];
                    _dt[i] = _dt[j];
                    _dt[j] = _row;
                }
            }
            else {
                if (_dt[j][_colName] < _dt[i][_colName]) {
                    _row = _dt[i];
                    _dt[i] = _dt[j];
                    _dt[j] = _row;
                }
            }
        }
    }

    return _dt;
};


//*****************************************************
//      private  windowEx class                       *
//*****************************************************
function WindowEx(_cfg) {
    this.ID = _cfg.ID;
    this.AID = (_cfg.Tag) ? _cfg.Tag.AID : null;
    this.Top = _cfg.Top || 0;
    this.Left = _cfg.Left || 0;
    this.Width = _cfg.Width;
    this.Height = _cfg.Height;
    this.TitleIcon = _cfg.TitleIcon;
    this.Title = _cfg.Title;
    this.IsShowHeader = _cfg.IsShowHeader == null ? true : _cfg.IsShowHeader;
    this.WaitStyle = _cfg.WaitStyle || "circle";
    this.Style = _cfg.Style || "DialogBlue";
    this.OX = _cfg.OX || 0;
    this.OY = _cfg.OY || 0;
    this.IsResize = _cfg.IsResize || false;
    this.MinWidth = _cfg.MinWidth || 250;
    this.MinHeight = _cfg.MinHeight || 200;
    this.IsLimtMove = _cfg.IsLimtMove == null ? true : _cfg.IsLimtMove;
    this.IndentWidth = _cfg.IndentWidth || 0;
    this.MoveHideContent = _cfg.MoveHideContent == null ? true : _cfg.MoveHideContent;

    this.State = _cfg.WindowState;
    this.PopupMode = _cfg.PopupMode;
    this.Event = _cfg.Event;

    this.Html = _cfg.Html;
    this.PageUrl = _cfg.PageUrl;

    this.Tag = _cfg.Tag;
    this.Config = _cfg;

    this.P = new Object();
    this.P.TWin = CoreTool.GetTopWin(_cfg.PopupMode);
    this.P.Div;
    this.P.TB;
    this.P.Frame;
    this.P.btnClose;
    this.P.IsActive = true;
    this.P.Cursor;

    this._Init();
};

WindowEx.prototype = {
    //============== public methods(inner) ===============
    Show: function () {
        //create elements
        var _div = this._CreateDiv();
        var _tb = this._CreateTable();
        var _frame = this.PageUrl ? this._CreateFrame() : null;

        if (this.PageUrl) {
            var _frame = this._CreateFrame();
            _tb.CDiv.appendChild(_frame);
        };

        //link elements
        _div.appendChild(_tb);

        //set src
        if (this.ContentType != "custom") window.setTimeout(this._GetLoadHandler(this), 25);

        //set list
        if (this.PopupMode != "dropdown") {
            var _twin = this.P.TWin;
            _twin.WindowCount++;

            for (var i = 0; i < _twin.WindowList.length; i++) {
                var _curWin = _twin.WindowList[i];
                if (_curWin.IsShowHeader) { _curWin._SetEnabled(false); }
            };

            _twin.WindowList.push(this);
        }
        else {
            if (window.LastPopupWin && window.LastPopupWin.AID != this.AID) window.LastPopupWin.Close();
            window.LastPopupWin = this;
        }

        //refresh
        this._Refresh();

        //return
        return this;
    },

    Append: function (_element) { this.P.TB.CDiv.appendChild(_element); },
    Close: function () { window.LastPopupWin._GetClosingHandler(window.LastPopupWin, true)(); },

    //============= private methods ==============
    _Init: function () {
        //get features
        var _t = this.Top;
        var _l = this.Left;
        var _w = this.Width;
        var _h = this.Height;

        //get document
        var _win = CoreTool.GetTopWin(this.PopupMode);
        var _doc = _win.document;

        //get client area parameters
        var _area = CoreTool.GetClientAreaParameters(_doc);
        if (this.PopupMode != "dropdown") {
            if (_t == 0) _t = _area.ScrollTop + (_area.Height - _h) / 2 - this.OY;
            if (_l == 0) _l = _area.ScrollLeft + (_area.Width - _w) / 2 - this.OX;
        }
        else {
            var _coords = CoreTool.GetEventCoords(document, this.Event, true);

            _l = _coords.X;
            if (this.OX != 0) {
                _l = _l - this.OX;
                _l = (_l + _w > _area.ScrollLeft + _area.Width) ? _area.Width - _w - 5 : _l;
            };

            _t = _coords.Y;

            if (_t + _h > _area.ScrollTop + _area.Height) {
                if (_t - _h - 18 >= _area.ScrollTop) {
                    _t = _t - _h - 18;
                }
                else {
                    _t = CoreTool.IsIE() ? _area.Height - _h : _area.Height - _h - 5;
                }
            }
        };
        this.Top = _t;
        this.Left = _l;

        if (!_win.WindowList) {
            _win.WindowList = new Array();
            _win.WindowCount = 0;
        };

        this._InitBody();
    },

    _InitBody: function () {
        var _bd = this.P.TWin.document.body;
        _bd.onmousemove = this._GetBodyMouseMoveHandler(this);
        _bd.onmousedown = this._GetBodyMouseDownHandler(this);
        _bd.onmouseup = this._GetBodyMouseUpHandler(this);
        _bd.onselectstart = function () { return false; };
    },

    _GetMaskDivOnClickHandler: function (_jc) { return function (event) { if (_jc.PopupMode == "dropdown") _jc._GetClosingHandler(_jc)(event); } },

    _CreateDiv: function () {
        //get window && document && level
        var _win = this.PopupMode == "dropdown" ? window : this.P.TWin;
        var _doc = _win.document;
        var _level = this.PopupMode == "dropdown" ? 1 : _win.WindowList.length + 1;

        //define parameters
        var _l, _t, _w, _h, _level;

        //get features
        if (this.State == "max") {
            var _area = CoreTool.GetClientAreaParameters(_doc);
            _l = 0;
            _t = 0;
            _w = _area.Width;
            _h = _area.Height;
        }
        else {
            _t = this.Top;
            _l = this.Left;
            _w = this.Width;
            _h = this.Height;
        };

        //create child window div
        var _div = _doc.createElement("DIV");
        _doc.body.appendChild(_div);
        _div.id = this.ID;
        _div.style.left = _l + "px";
        _div.style.top = _t + "px";
        _div.style.width = _w + "px";
        _div.style.height = _h + "px";
        _div.style.position = "absolute";
        if (!this.IsShowHeader) _div.style.padding = "0px";
        _div.style.zIndex = _level * 99999999;
        _div.className = "winBase win" + this.Style + (this.IsShowHeader ? " winBase_dialogDiv win" + this.Style + "_dialogDiv" : " win_dropdownDiv");
        _div.CloseWindow = this.CloseWindow = this._GetClosingHandler(this);

        //mask div
        var _isMaskTop = this.PopupMode == "dropdown" ? false : true;
        this.P.MaskFrame = CoreTool.MaskArea(this.ID + "_mask_iframe", _t, _l - 1, this.IsShowHeader ? _w + 4 : _w, this.IsShowHeader ? _h + 1 : _h, _level * 99, this._GetMaskDivOnClickHandler(this), _isMaskTop);

        //crea move div
        this._CreateSizeDiv(_div, _doc, _level);

        //retrun
        this.P.Div = _div;
        return _div;
    },

    _CreateSizeDiv: function (_div, _doc, _level) {
        var _mdiv = _doc.createElement("DIV");
        _doc.body.appendChild(_mdiv);

        for (var p in _div.style) { try { if (p != "font") _mdiv.style[p] = _div.style[p]; } catch (e) { } };

        _mdiv.style.zIndex = _level * 99999999 + 1;
        _mdiv.style.border = "dashed 1px gray";
        _mdiv.style.display = "none";
        _mdiv.style.minWidth = this.MinWidth + "px";
        _mdiv.style.minHeight = this.MinHeight + "px";
        _mdiv.onmousemove = this._GetMDivMouseMoveHandler(this);

        this.P.MDiv = _mdiv;
    },

    _CreateTable: function () {
        //get window && document && level
        var _win = this.PopupMode == "dropdown" ? window : this.P.TWin;
        var _doc = _win.document;

        //create table
        var _tb = CoreTool.CreateTable(_doc, "table");
        _tb.onselectstart = function () { return false; };

        //create title
        if (this.IsShowHeader && this.PopupMode != "dropdown") {
            var _isFixed = !this.IsResize;

            //tr1
            var _tr = CoreTool.CreateTr(_tb, "tr1");
            this._CreateBorderTd(_tr, "11", "lt", "Size");
            this._CreateBorderTd(_tr, "12", "t", "Size");
            this._CreateBorderTd(_tr, "13", "rt", "Size");

            //tr2
            var _tr = CoreTool.CreateTr(_tb, "tr2");
            this._CreateBorderTd(_tr, "21", "l", "Size");

            var _td = this._CreateBorderTd(_tr, "22", "Move", "Move", '<div class="' + (this.TitleIcon ? this.TitleIcon : "icon") + '"></div><div class="text"></div><div class="close"></div>');
            _td.childNodes[1].innerHTML = this.Title ? this.Title : "";

            var _btn = _td.childNodes[2];
            _btn.onmouseover = this._CloseButtonMouseMove(this, _btn, "in");
            _btn.onmouseout = this._CloseButtonMouseMove(this, _btn, "out");
            _btn.onclick = this._GetClosingHandler(this);
            _btn.Window = this;
            _btn.onselectstart = function () { return false; };
            this.P.btnClose = _btn;

            this._CreateBorderTd(_tr, "23", "r", "Size");
        };

        //tr3
        var _tr = CoreTool.CreateTr(_tb, "tr3");
        _tr.Type = "work";
        if (this.IsShowHeader && this.PopupMode != "dropdown") this._CreateBorderTd(_tr, "31", "l", "Size");
        _tb.ContentTd = CoreTool.CreateTd(_tr, "td td32", '<div class="divContent"></div>');
        if (this.IsShowHeader && this.PopupMode != "dropdown") this._CreateBorderTd(_tr, "33", "r", "Size");

        //tr4
        if (this.IsShowHeader && this.PopupMode != "dropdown") {
            var _tr = CoreTool.CreateTr(_tb, "tr4");
            this._CreateBorderTd(_tr, "41", "lb", "Size");
            this._CreateBorderTd(_tr, "42", "b", "Size");
            this._CreateBorderTd(_tr, "43", "rb", "Size");
        }

        //create
        var _chDiv = _tb.ContentTd.childNodes[0];

        if (this.WaitStyle != "none" && !this.Html && this.PageUrl) _chDiv.className = _chDiv.className + " loading" + this.WaitStyle;
        if (this.PopupMode == "dropdown") {
            _chDiv.style.width = this.P.Div.offsetWidth - 2 + "px";
            _chDiv.style.height = this.P.Div.offsetHeight - 2 + "px";
        };
        this.CDiv = _tb.CDiv = _chDiv;
        if (this.Html) _chDiv.innerHTML = this.Html;

        //return table
        this.P.TB = _tb;
        return _tb;
    },

    _CreateBorderTd: function (_tr, _idx, _action, _actionType, _html, _cursorCss) {
        var _css = !this.IsResize ? "td td" + _idx : "td td" + _idx + " td" + _idx + "-c";
        var _td = CoreTool.CreateTd(_tr, _css);
        _td.Cursor = "td" + _idx + "-c";
        _td.onmousemove = this._GetWinMouseMoveHandler(this, _td);
        _td.onmousedown = this._GetWinMouseDownHandler(this, _td, _action, _actionType, _cursorCss);
        _td.onmouseup = this._GetWinMouseUpHandler(this, _td);
        if (_html) _td.innerHTML = _html;
        return _td;
    },

    _CreateFrame: function () {
        //get window && document && level
        var _win = this.PopupMode == "dropdown" ? window : this.P.TWin;
        var _doc = _win.document;

        //create iframe
        var _frame = _doc.createElement("IFRAME");
        _frame.style.display = this.WaitStyle != "none" ? "none" : "block";
        _frame.style.width = "100%";
        _frame.style.height = "100%";
        _frame.className = "frame";
        _frame.frameBorder = "0";
        _frame.scrolling = "no";
        _frame.Tag = this.Tag;
        _frame.LoadCallback = this._GetLoadCallbackHandler(this);

        //return
        this.P.Frame = _frame;
        return _frame;
    },

    _GetLoadHandler: function (_jc) { return function () { if (_jc.PageUrl) { _jc.P.Frame.src = _jc.PageUrl; } } },

    _GetLoadCallbackHandler: function (_jc) {
        return function () {
            _jc.P.Frame.style.display = "block";
            _jc.P.Frame.parentNode.style.backgroundImage = "url('')";
        }
    },

    _CloseButtonMouseMove: function (_jc, _btn, _action) {
        return function () {
            _jc.P.IsClosing = _action == "in" ? true : false;
            if (!_jc.P.IsActive) { _btn.style.cursor = "not-allowed"; return }
            _btn.style.cursor = ""
            _btn.className = _action == "in" ? "closeOver" : "close";
        }
    },

    _GetClosingHandler: function (_jc, _isClosed) {
        return function (_evt) {
            //if is dropdown && status is open then return
            var _tag = _jc.Tag;
            var _evt = window.event || _evt;

            if (_jc.PopupMode == "dropdown" && !_isClosed && _tag && (!window.LastPopupWin || window.LastPopupWin.AID == _jc.AID) && _tag.Status == "open" && CoreTool.IsInCss(_evt.srcElement || _evt.target, "dropdown_tag")) return;

            //set stauts
            if (_tag) _tag.Status = "close";

            //process iframe close event
            if (!_jc.P.IsActive) { return; };

            //get top window && document
            var _twin = _jc.P.TWin;
            var _topDoc = _twin.document;

            //remove child window
            var _isError = false;
            try {
                _topDoc.body.removeChild(_jc.P.Div);
                _topDoc.body.removeChild(_jc.P.MDiv);
                window.document.body.removeChild(_jc.P.MaskFrame);
            }
            catch (e) { _isError = true; };
            if (_isError) return;

            //remove child window
            if (_jc.PopupMode != "dropdown") {
                try {
                    if (_twin.WindowList) {
                        _twin.WindowCount--;
                        _twin.WindowList.pop();
                        if (_twin.WindowList.length > 0) { _twin.WindowList[_twin.WindowList.length - 1]._SetEnabled(true); }
                    }
                }
                catch (e) { };

                //hidden top window mask
                if (_twin.WindowCount == 0) {
                    var _fmask = _topDoc.getElementById("maskFace");
                    if (_fmask) _fmask.style.display = "none";
                }
            };

            //hidden parent window mask
            var _mf = document.getElementById("maskFace");
            if (_mf) _mf.style.display = "none";

            //call child window close event
            if (_tag && _tag.AfterClosed) { _tag.AfterClosed(); }
        }
    },

    _ShowMaskArea: function (_jc) {
        var _p = _jc.P;
        for (var i = 0; i < _p.TWin.WindowList.length; i++) {
            var _win = _p.TWin.WindowList[i];
            var _mdiv = _win.P.MDiv;
            _mdiv.style.borderWidth = _win.P.IsActive ? "1px" : "0px";
            _mdiv.style.display = "block";
        }
    },

    _GetWinMouseMoveHandler: function (_jc, _td) {
        return function (event) {
            _td.style.cursor = _jc.P.IsActive ? "" : "default";
        }
    },

    _GetWinMouseDownHandler: function (_jc, _td, _action, _actionType) {
        return function (event) {
            var _p = _jc.P;
            if (!_p.IsActive || _p.IsClosing || (!_jc.IsResize && _action != "Move")) return;

            _p.TWin.MJC = _jc;
            _p.Action = _action;
            _p.ActionType = _actionType
            _p.MDiv.className = _td.Cursor;
            if (_p.Frame && _jc.MoveHideContent) _p.Frame.style.display = "none";

            _jc._InitBody();
            _jc._ShowMaskArea(_jc);
        }
    },

    _GetWinMouseUpHandler: function (_jc, _td) {
        return function () {
            var _p = _jc.P;
            if (!_p.IsActive) return;
            if (_p.Frame) _p.Frame.style.display = "block";
            if (_p.MDiv) _p.MDiv.style.display = "none";
            _p.TWin.MJC = null;
        }
    },

    _GetMDivMouseMoveHandler: function (_jc) {
        return function () {
            if (_jc.P.Cursor && _jc.IsActive) _jc.P.MDiv.style.cursor = _jc.P.Cursor;
        }
    },

    _GetBodyMouseMoveHandler: function (_jc) {
        return function (event) {
            var _twin = _jc.P.TWin;
            var _awin = _twin.MJC;

            if (!_twin.MJC || !_awin.P.IsActive) return;
            var _P = _awin.P;
            var _evt = event || _P.TWin.event;
            if (!_evt) return;

            var _pos = CoreTool.GetEventCoords(_P.TWin.document, _evt);

            var _ox, _oy;
            if (_P.Action == "Move") {
                _ox = _awin.Pos.X - parseInt(_P.Div.style.left);
                _oy = _awin.Pos.Y - parseInt(_P.Div.style.top);
            }
            else {
                _ox = _awin.Pos.X - parseInt(_P.MDiv.style.left);
                _oy = _awin.Pos.Y - parseInt(_P.MDiv.style.top);
            }
            var _mox = _pos.X - _awin.Pos.X;
            var _moy = _pos.Y - _awin.Pos.Y;

            var _area = CoreTool.GetClientAreaParameters(_twin.document);
            var _x = _pos.X - _ox;
            var _y = _pos.Y - _oy;
            if (isNaN(_y) || _y < 0 || isNaN(_x) || _x < 0) return;

            if (_P.ActionType == "Move") {
                if (_jc.IsLimtMove && (_pos.X < 1 || _pos.Y < 1 || _x + _awin.Width >= _area.ScrollLeft + _area.Width - 4 || _x < 1 || _y + _awin.Height >= _area.ScrollTop + _area.Height - 4 || _y < 1 || isNaN(_pos.Y) || isNaN(_pos.Y))) return;
                _P.MaskFrame.style.left = _x + "px";
                _P.MaskFrame.style.top = _y + "px";

                _P.Div.style.left = _x + "px";
                _P.Div.style.top = _y + "px";

                if (_P.MDiv) {
                    _P.MDiv.style.left = _x + "px";
                    _P.MDiv.style.top = _y + "px";
                }

                _awin.Pos = _pos;
            }
            else if (_awin.P.ActionType == "Size" && _awin.IsResize) {
                var _mdiv = _P.MDiv;
                _mdiv.Width = parseInt(_mdiv.style.width);
                if (_jc.IsLimtMove && (_pos.X < 1 || _pos.Y < 1 || _x + _mdiv.Width >= _mdiv.scrollLeft + _area.Width - 4 || _x < 1 || _y + _mdiv.height >= _area.ScrollTop + _area.Height - 4 || _y < 1 || isNaN(_pos.Y) || isNaN(_pos.Y))) return;
                var _x = _x + "px";
                var _y = _y + "px";
                var _w = parseInt(_mdiv.style.width);
                var _h = parseInt(_mdiv.style.height);
                var _rx = 0, _ry = 0, _rw = 0, _rh = 0;
                switch (_P.Action) {
                    case "lt":
                        _rx = _x;
                        _ry = _y;
                        _rw = _w - _mox;
                        _rh = _h - _moy;
                        break;
                    case "t":
                        _ry = _y;
                        _rh = _h - _moy;
                        break;
                    case "rt":
                        _ry = _y;
                        _rw = _w + _mox;
                        _rh = _h - _moy;
                        break;
                    case "l":
                        _rx = _x;
                        _rw = _w - _mox;
                        break;
                    case "r":
                        _rw = _w + _mox;
                        break;
                    case "lb":
                        _rx = _x;
                        _rw = _w - _mox;
                        _rh = _h + _moy;
                        break;
                    case "b":
                        _rh = _h + _moy;
                        break;
                    case "rb":
                        _rw = _w + _mox;
                        _rh = _h + _moy;
                        break;
                }

                if (_rw && _rw < _awin.MinWidth) { return } else { if (_rw) _mdiv.style.width = _rw + "px" };
                if (_rh && _rh < _awin.MinHeight) { return } else { if (_rh) _mdiv.style.height = _rh + "px" };
                if (_rx) { _mdiv.style.left = _rx };
                if (_ry) { _mdiv.style.top = _ry };
                _awin.Pos = _pos;
            }
        }
    },

    _GetBodyMouseDownHandler: function (_jc) {
        return function (event) {
            var _twin = _jc.P.TWin;
            if (!_twin.MJC || !_twin.MJC.P.IsActive) { return; };
            _twin.MJC.Pos = CoreTool.GetEventCoords(_jc.P.TWin.document, event || _twin.event);
            _twin.MJC.P.IsActive = true;
            _twin.document.body.style.cursor = _twin.MJC.P.Cursor;
        }
    },

    _GetBodyMouseUpHandler: function (_jc) {
        return function () {
            var _twin = _jc.P.TWin;

            for (var i = 0; i < _twin.WindowList.length; i++) {
                _twin.WindowList[i].P.MDiv.style.display = "none";
            }

            if (_jc.P.Frame) _jc.P.Frame.style.display = "block";
            if (_jc.P.ActionType == "Size") { _jc.P.MDiv.style.display = "none"; _jc._Resize() };
            _twin.MJC = null;
            _twin.document.body.onselectstart = null;
            _twin.document.body.style.cursor = "default";
        }
    },

    _Refresh: function () {
        var _div = this.P.TB.CDiv;
        _div.style.height = (_div.parentNode.offsetHeight || _div.parentNode.clientHeight) + "px";
        _div.style.display = "block";
    },

    _Resize: function () {
        var _mdiv = this.P.MDiv;
        var _mframe = this.P.MaskFrame;
        var _div = this.P.Div;
        var _tb = this.P.TB;
        var _cdiv = this.CDiv;

        var _area = this._GetNoWorkArea();
        var _w = parseInt(_mdiv.style.width) - 2;
        var _h = parseInt(_mdiv.style.height) - 2;

        this.Width = parseInt(_mdiv.style.width);
        this.Height = parseInt(_mdiv.style.height);
        _mframe.style.left = _div.style.left = _mdiv.style.left;
        _mframe.style.top = _div.style.top = _mdiv.style.top;
        _mframe.style.width = _div.style.width = _mdiv.style.width;
        _mframe.style.height = _div.style.height = _mdiv.style.height;

        _tb.style.height = _mdiv.style.height;
        _cdiv.style.width = (_w - _area.Width) + "px";
        _cdiv.style.height = _tb.ContentTd.style.height = (_h - _area.Height) + "px";
    },

    _GetNoWorkArea: function () {
        var _tb = this.P.TB;
        var _w = 0, _h = 0;
        for (var i = 0; i < _tb.rows.length; i++) {
            var _tr = _tb.rows[i];
            if (_tr.Type != "work") {
                _h += _tr.cells[0].offsetHeight;
            }

            if (!_w) _w = _tr.cells[0].offsetWidth + _tr.cells[2].offsetWidth;
        }

        return { Width: _w, Height: _h };
    },

    _SetEnabled: function (_val) {
        this.P.IsActive = _val;
        this.P.btnClose.style.cursor = _val ? "cursor" : "default";
    }
};