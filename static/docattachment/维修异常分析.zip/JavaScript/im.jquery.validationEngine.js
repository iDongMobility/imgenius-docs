﻿(function ($) {
    if ($.validationEngineLanguage == undefined || $.validationEngineLanguage.allRules == undefined)
        alert("Please include im.jquery.validationEngine.js AFTER the translation file");
    else {
        $.validationEngineLanguage.allRules["relativedate"] = {
            // 日期或相对日期
            "regex": /^((今天|本周初|本周末|本月初|本月末|本季初|本季末)([\+\-]\d{1,10})$)|(^\d{4}[\/\-](0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])$)|(^(今天|本周初|本周末|本月初|本月末|本季初|本季末))$/,
            "alertText": "* 请输入合法的日期或相对日期"
        };

        $.validationEngineLanguage.allRules["mutilPhone"] = {
            // 多个电话号码
            "func": function (field, rules, i, options) {
                var text = field.val();
                if (!text)
                    return true;
                var phoneNumbers = text.split(",");
                var pattern = new RegExp("^([\+][0-9]{1,3}[ \.\-])?([\(]{1}[0-9]{2,6}[\)])?([0-9 \.\-\/]{3,20})((x|ext|extension)[ ]?[0-9]{1,4})?$");
                for (var i = 0; i < phoneNumbers.length; i++) {
                    if (!phoneNumbers[i] || phoneNumbers[i].length != 11 || !pattern.test(phoneNumbers[i])) {
                        return false;
                    }
                }
                return true;
            },
            "alertText": "* 无效的电话号码"
        };
    }
})(jQuery_1_8_2);