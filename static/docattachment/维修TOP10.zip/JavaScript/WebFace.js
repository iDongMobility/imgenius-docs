﻿//*****************************************************
//      WebFace Class                                 *
//*****************************************************
function WebFace() { };

//*****************************************************
//  next methods is correlation from WebTool          *
//*****************************************************
WebFace.ShowDialog = function (_cfg) { return DialogTool.Show(_cfg); };
WebFace.GetDialogArguments = function () { var _args = new Object(); _args.Arguments = DialogTool.GetTag(); _args.Save = DialogTool.Save; _args.Close = DialogTool.Close; _args.LoadCallback = DialogTool.LoadCallback; return _args; };

WebFace.ShowMessage = function (_prompt, _t, _l, _w, _h, _ox, _oy, _isShowBorder, _css) { WebTool.ShowMessage(_prompt, _t, _l, _w, _h, _ox, _oy, _isShowBorder, _css); };
WebFace.HideMessage = function () { WebTool.HideMessage(); };

WebFace.AddEvent = function (_sender, _eventName, _fun) { CoreTool.AddEvent(_sender, _eventName, _fun); };
WebFace.RemoveEvent = function (_sender, _eventName, _fun) { CoreTool.RemoveEvent(_sender, _eventName, _fun); };
WebFace.GetEventCoords = function (_doc, _evt, _isCalculateOffset) { return CoreTool.GetEventCoords(_doc, _evt, _isCalculateOffset) };
WebFace.StopBubble = function (e) { CoreTool.StopBubble(e); }


//*****************************************************
//  next methods is correlation webControls           *
//*****************************************************
WebFace.CreateDateTimePickerEx = function (_cfg) {
    var _dtp = new DateTimePickerEx(_cfg);
    _dtp.InitFace();
    return _dtp;
};


//*****************************************************
//        next methods is extend                      *
//*****************************************************
WebFace.GetElement = function (_containerId, _controlId) {
    var allElements = document.getElementsByTagName("*");
    for (var i = 0; i < allElements.length; i++) {
        var _id = allElements[i].id;

        if (_id == null) {
            continue;
        };

        if (_containerId != null) {
            if (_id.indexOf(_containerId) >= 0 && _id.indexOf(_controlId) >= 0) { return allElements[i]; }
        }
        else {
            if (_id.indexOf(_controlId) >= 0) { return allElements[i]; }
        }
    }
};

WebFace.Call = function (_funStr, _p1, _p2, _p3, _p4, _p5, _p6) {
    if (typeof (_funStr) == "function") {
        _funStr(_p1, _p2, _p3, _p4, _p5, _p6);
        return;
    }
    if (_funStr == null || _funStr == "" || _funStr == undefined) return;

    if (_funStr.indexOf(".") > 0) {
        var _className = _funStr.substring(0, _funStr.lastIndexOf("."));
        var _methodName = _funStr.substring(_funStr.lastIndexOf(".") + 1);

        var _class = eval(_className);
        if (_class == undefined) {
            alert("class [" + _className + "] is undefined!");
            return;
        };

        if (_class[_methodName] == undefined) {
            alert("[" + _funStr + "] is undefined!");
            return;
        };
        _class[_methodName](_p1, _p2, _p3, _p4, _p5, _p6);
    }
    else {
        eval(_funStr)(_p1, _p2, _p3, _p4, _p5, _p6);
    }
};

WebFace.Format = function (_val, _decimalPlaces, _isGroup) {
    //process dots
    if (_val == null) return null;
    var _val = _val.toString();
    var _dotIndex = _val.indexOf(".");
    if (_val == "") _val = 0;
    if (_decimalPlaces <= 0 && _dotIndex >= 0) {
        if (_dotIndex == 0) _val = "0." + _val;
        return _val;
    };

    if (_dotIndex > 0) {
        var _tempStr = _val.substr(_dotIndex, _val.length - _dotIndex);
        var _dotNum = _tempStr.length - 1;

        if (_tempStr.length - 1 > _decimalPlaces) {
            _val = _val.substring(0, _dotIndex) + _tempStr.substring(0, _decimalPlaces + 1);
        }
        else {
            for (var i = _dotNum; i < _decimalPlaces; i++) {
                _val = _val + "0";
            }
        }
    }
    else if (_decimalPlaces > 0) {
        _val = _val + ".0";

        for (var i = 1; i < _decimalPlaces; i++) {
            _val = _val + "0";
        }
    };

    if (_isGroup) {
        var _arr = _val.split(".");
        _val = _arr[0].replace(/\B(?=(?:[0-9]{3})+$)/g, ',') + "." + (_arr.length == 1 ? "" : _arr[1]);
    };

    return _val;
};

WebFace.GetLength = function (_str) {
    var _length = 0;

    for (var i = 0; i < _str.length; i++) {
        _length = _length + (_str.substr(i, 1).charCodeAt(0) > 255 ? 2 : 1);
    };

    return _length;
};

WebFace.JSON = function (o) {
    var _arr = { '\b': '\\b', '\t': '\\t', '\n': '\\n', '\f': '\\f', '\r': '\\r', '"': '\\"', '\\': '\\\\' };

    if (o == null) return "null";
    var v = [];
    var i;
    var c = o.constructor;
    if (c == Number) {
        return isFinite(o) ? o.toString() : WebFace.JSON(null);
    } else if (c == Boolean) {
        return o.toString();
    } else if (c == String) {
        if (/["\\\x00-\x1f]/.test(o)) {
            o = o.replace(/([\x00-\x1f\\"])/g, function (a, b) {
                var c = _arr[b];
                if (c) return c;
                c = b.charCodeAt();
                return '\\u00' + Math.floor(c / 16).toString(16) + (c % 16).toString(16);
            });
        }
        return '"' + o + '"';
    } else if (c == Array) {
        for (i = 0; i < o.length; i++) {
            v.push(WebFace.JSON(o[i]));
        }
        return "[" + v.join(",") + "]";
    } else if (c == Date) {
        return WebFace.JSON(o.getFullYear() + "/" + o.getMonth() + "/" + o.getDate());
    }
    if (typeof o.JSON == "function") return o.JSON();
    if (typeof o == "object") {
        for (var attr in o) {
            if (typeof o[attr] != "function") {
                v.push('"' + attr + '":' + WebFace.JSON(o[attr]));
            }
        }
        if (v.length > 0) return "{" + v.join(",") + "}";
        return "{}";
    }
    return o.toString();
};

WebFace.CreateObject = function (_json) {
    var _r = new Object();
    if (_json) {
        eval("_r.Result=" + _json.replace(/Ajax.Web./ig, ""));
        return _r.Result;
    }
    return _r;
};

WebFace.CreateElement = function (_tag, _css, _html, _cc) { return CoreTool.CreateEelement(_tag, _css, _html, _cc) };
WebFace.CreateTable = function (_doc, _css, _cc) { return CoreTool.CreateTable(_doc, _css, _cc) };
WebFace.CreateTr = function (_tb, _css) { return CoreTool.CreateTr(_tb, _css) };
WebFace.CreateTd = function (_tr, _css, _html) { return CoreTool.CreateTd(_tr, _css, _html) };
WebFace.StopBubble = function (e) { return CoreTool.StopBubble(e) };



//*****************************************************
//     next methods is system extend                  *
//*****************************************************
Function.prototype.Inherit = function (_childClass, _baseClass) {
    for (var _baseProperty in _baseClass.prototype) {
        var _isOverride = false;
        for (var _childProperty in _childClass) {
            if (_baseProperty == _childProperty) { _isOverride = true; break; }
        }
        if (!_isOverride) this.prototype[_baseProperty] = _baseClass.prototype[_baseProperty];
    }

    var _objBase = new _baseClass();
    for (var _baseProperty in _objBase) {
        var _isOverride = false;
        for (var _childProperty in _childClass) {
            if (_baseProperty == _childProperty) {
                _isOverride = true;
                break;
            }
        }
        if (!_isOverride) { _childClass[_baseProperty] = _objBase[_baseProperty]; }
    }
};

//*****************************************************
//     next methods is extend class                   *
//*****************************************************
function DataSet(t) {
    this.Tables = [];
    this.addTable = function (t) {
        this.Tables.push(t);
    };
    if (t != null) {
        for (var i = 0; i < t.length; i++) {
            this.addTable(t[i]);
        }
    }
};

function DataTable(c, r) {
    this.Columns = [];
    this.Rows = [];
    this.addColumn = function (name, type) {
        this.Columns.push({ Name: name, __type: type });
    };

    this.addRow = function (row) {
        this.Rows.push(row);
    };
    if (c != null) {
        for (var i = 0; i < c.length; i++)
            this.addColumn(c[i][0], c[i][1]);
    }
    if (r != null) {
        for (var y = 0; y < r.length; y++) {
            var row = {};
            for (var z = 0; z < this.Columns.length && z < r[y].length; z++)
                row[this.Columns[z].Name] = r[y][z];
            this.addRow(row);
        }
    }
};

function Dictionary(type, items) {
    this.Length = items.length;
    if (items != null && !isNaN(items.length)) {
        for (var i = 0; i < items.length; i++) {
            var _p = items[i][0];
            var _v = items[i][1];
            this[_p] = _v;
        }
    }
};

function NameValueCollection(type, items) {
    this.Length = items.length;
    if (items != null && !isNaN(items.length)) {
        for (var i = 0; i < items.length; i++) {
            var _p = items[i][0];
            var _v = items[i][1];
            this[_p] = _v;
        }
    }
};