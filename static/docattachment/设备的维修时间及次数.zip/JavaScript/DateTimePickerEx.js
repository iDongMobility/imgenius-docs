﻿//*************************************************
//          dataGrid class define                *
//*************************************************
window.DTPOINTER = 0;
function DateTimePickerEx(_cfg) {
    //============= set default value =============
    if (!_cfg.Value) {
        var _now = new Date();
        var _yy = _now.getFullYear();
        var _mm = CoreTool.FormatCode(_now.getMonth(), 2);
        var _dd = CoreTool.FormatCode(_now.getDate(), 2);
        var _hh = CoreTool.FormatCode(_now.getHours(), 2);
        var _mn = CoreTool.FormatCode(_now.getMinutes(), 2);
        var _ss = CoreTool.FormatCode(_now.getSeconds(), 2);
        _cfg.Value = _cfg.Format.toLocaleLowerCase() != "hh:mm:ss" ? (_yy + "-" + _mm + "-" + _dd + " " + _hh + ":" + _mn + ":" + _ss) : (_hh + ":" + _mn + ":" + _ss);
    }

    //============= public properties =============
    this.Container = document.getElementById(_cfg.ContainerId);
    this.Width = _cfg.Width;
    this.Height = _cfg.Height;
    this.Value = _cfg.Value;
    this.Align = _cfg.Align || "left";
    this.Enabled = _cfg.Enabled == null ? true : _cfg.Enabled;
    this.Visible = _cfg.Visible == null ? true : _cfg.Visible;
    this.Format = _cfg.Format || "yyyy-MM-dd";
    this.Status = "close";

    this.IsShowBorder = _cfg.IsShowBorder == null ? true : _cfg.IsShowBorder;
    this.IsShowCheckBox = _cfg.IsShowCheckBox == null ? true : _cfg.IsShowCheckBox;
    this.Checked = _cfg.Checked == null ? true : _cfg.Checked;
    this.IsShowButton = _cfg.IsShowButton == null ? true : _cfg.IsShowButton;

    this.ValueChanged = _cfg.ValueChanged;

    //============== private fields ==============
    this.P = new Object();
    this.P.ImgPath = WebConfig.RsCtrlsUrl + "/Images/DateTimePicker";
    this.P.OVal = this.Value;
    this.P.Ctrls = new Array();
    this.P.ValCtrls = new Array();
    this.P.TxtCtrls = new Array();
    this.P.CheckBox;
    this.P.IsFocused = true;
    var _time = new Date();
    this.AID = _time.getHours() + "l" + _time.getMinutes() + "m" + _time.getSeconds() + "n" + _time.getMilliseconds() + window.DTPOINTER;
    window.DTPOINTER++;
};

DateTimePickerEx.prototype = {

    //============= private methods ==============
    _ValueChanged: function () {
        var _value = this.GetValue();
        if (this.ValueChanged && this.P.OVal != _value) { this.ValueChanged(this, _value); }
        this.P.OVal = _value;
    },

    _GetCellClickHandler: function (_jc) { return function () { _jc.Status = "close"; } },

    _GetChkClickHandler: function (_jc, _chk) {
        return function () {
            _jc.Checked = _chk.checked;
            _jc.SetEnabled(_chk.checked, "chk");
            _jc._ValueChanged();
        }
    },

    _GetSpClickHandler: function (_jc, _td, _isSetStatus) {
        return function () {
            if (_isSetStatus == null) _jc.Status = "close";
            if (!_td.Ctrl.disabled) _td.Ctrl.focus();
        }
    },

    _GetCtrlFocusedHandler: function (_jc, _txt) {
        return function () {
            if (window.LastPopupWin && window.LastPopupWin.Tag && window.LastPopupWin.AID != _jc.AID) {
                window.LastPopupWin.Tag.Status = "close";
                window.LastPopupWin._GetClosingHandler(window.LastPopupWin, true)();
            }

            _jc.P.IsFocused = true;
            if (!_txt) return;

            _txt.OVal = (!_txt.OVal) ? _txt.defaultValue : _txt.value;
            _txt.select();
            _jc.OVal = _jc.GetValue();
        }
    },

    _GetCtrlBlurHandler: function (_jc, _txt) {
        return function () {
            _jc.P.IsFocused = false;
            if (_txt) {
                if (!_jc._Validate(_txt)) return;
                _jc._ResetDays(_txt);
                _jc._FF(_txt);
                _jc.Value = _jc.GetValue();
                _jc._ValueChanged();
            }
        }
    },

    _GetTxtKeydownHandler: function (_jc, _txt) {
        return function (event) {
            return _jc._TxtOnkeydown(_txt, event);
        }
    },

    _TxtOnkeydown: function (_txt, event) {
        //processing begin
        var _tr = this.Tr;

        //get key code
        var _evt = event || window.event;
        var _keyCode = _evt.keyCode;

        //if is not digitis to return
        if (_evt.ctrlKey) { _evt.returnValue = true; return; };
        if (_keyCode == 39 || _keyCode == 13)//left arrow enter
        {
            _evt.returnValue = this._MoveNext(_txt);
        }
        else if (_keyCode == 37)//right arrow
        {
            _evt.returnValue = this._MovePrevious(_txt);
        }
        else if (_keyCode == 38)//up arrow
        {
            _evt.returnValue = true;
            this._Spinner(_txt, "up");
        }
        else if (_keyCode == 40)//down arrow
        {
            _evt.returnValue = true;
            this._Spinner(_txt, "down");
        }
        else if (_keyCode == 36)//home
        {
            this.P.ValCtrls[0].focus();
            _evt.returnValue = false;
        }
        else if (_keyCode == 35)//end
        {
            this.P.ValCtrls[this.P.ValCtrls.length - 1].focus();
            _evt.returnValue = false;
        }
        else if (((_keyCode >= 47 && _keyCode <= 58) || (_keyCode >= 96 && _keyCode <= 105)) && (!_evt.shiftKey)) {
            _evt.returnValue = true;
        }
        else if (_keyCode < 30 || _keyCode == 33 || _keyCode == 34 || _keyCode == 45 || _keyCode == 46) {
            _evt.returnValue = true;
        }
        else {
            _evt.returnValue = false;
        };

        return _evt.returnValue;
    },

    _MoveNext: function (_txt) {
        if (_txt.Idx < this.P.TxtCtrls.length - 1) {
            this.P.TxtCtrls[_txt.Idx + 1].focus();
            return true;
        };

        return false;
    },

    _MovePrevious: function (_txt) {
        if (_txt.Idx > 0) {
            this.P.TxtCtrls[_txt.Idx - 1].focus();
            return true;
        };

        return false;
    },

    _Spinner: function (_txt, _action) {
        //define range
        var _rng = this._GetRange(_txt);

        //spinner value
        var _ff = _txt._FF;
        var _val = _txt.value;
        if (_val.substring(0, 1) == "0") _val = _val.substr(1, _val.length - 1);

        if (_action == "up") {
            if (parseInt(_val) < _rng.Max) {
                _val = parseInt(_val) + 1;
            }
            else if (_ff != 'yyyy') {
                _val = _rng.Min;
            }
        }
        else {
            if (parseInt(_val) > _rng.Min) {
                _val = parseInt(_val) - 1;
            }
            else if (_ff != "yyyy") {
                _val = _rng.Max;
            }
        };

        _txt.value = _val;

        //format
        this._ResetDays(_txt);
        this._FF(_txt);

        //call event
        this._ValueChanged();

        window.setTimeout(this._GetDelaySelectHandler(_txt), 50);
    },

    _GetDelaySelectHandler: function (_txt) { return function () { _txt.select(); } },

    _Validate: function (_txt) {
        //get current value
        var _val = parseFloat(_txt.value);

        //if not number return
        if (isNaN(_val) || !CoreTool.IsNumeric(_txt.value)) {
            _txt.value = _txt.OVal;
            return false;
        };

        //format
        this._FF(_txt);

        //trim first 0
        var _val = _txt.value;
        if (_val.substring(0, 1) == "0") _txt.value = _val.substr(1, _val.length - 1);

        //get range
        var _rng = this._GetRange(_txt);
        if (_val < _rng.Min || _val > _rng.Max) {
            _txt.value = _txt.OVal;
            return false;
        };

        //return
        return true;
    },

    _GetRange: function (_txt) {
        var _rng = new Object();

        var _min, _max;
        switch (_txt._FF) {
            case "yyyy":
                _min = 1900;
                _max = 9999;
                break;

            case "MM":
                _min = 1;
                _max = 12;
                break;

            case "dd":
                _min = 1;
                _max = this._GetMaxDays(_txt);
                break;

            case "HH":
                _min = 0;
                _max = 23;
                break;

            case "hh":
                _min = 1;
                _max = 12;
                break;

            case "mm":
            case "ss":
                _min = 0;
                _max = 59;
                break;
        };

        _rng.Max = _max;
        _rng.Min = _min;

        return _rng;
    },

    _FF: function (_txt) {
        //get current value
        var _val = _txt.value;

        //get value
        var _now = new Date();
        switch (_txt._FF) {
            case "yyyy":
                if (_val == "") {
                    _val = (new Date()).getFullYear();
                }
                else if (_txt.value.length == 1) {
                    _val = "200" + _val;
                }
                else if (_txt.value.length == 2) {
                    _val = "20" + _val;
                }
                else if (_txt.value.length == 3) {
                    _val = "2" + _val;
                }
                break;

            case "MM":
                if (_val == "") _val = _now.getMonth();
                break;

            case "dd":
                if (_val == "") _val = _now.getDate();
                break;

            case "HH":
                if (_val == "") _val = _now.getHours();
                break;

            case "hh":
                if (_val == "") { _val = _now.getHours(); if (_val > 12) { _val = _val - 12; } };
                break;

            case "mm":
                if (_val == "") { _val = _now.getMinutes(); }
                break;

            case "ss":
                if (_val == "") { _val = _now.getSeconds(); }
                break;
        };

        if (_val.length == 1) _val = "0" + _val;

        //set value
        _txt.value = _val;
    },

    _ResetDays: function () {
        var _maxDays = this._GetMaxDays();

        var _tDays = this._GetCtrlByFF("dd");
        if (_tDays) {
            _val = _tDays.value;

            if (parseFloat(_val) > parseFloat(_maxDays)) {
                _tDays.value = _maxDays;
            }
        };
    },

    _GetMonth: function () {
        var _tMonth = this._GetCtrlByFF("MM");
        if (_tMonth) return parseFloat(_tMonth.value);
        return null;
    },

    _GetMaxDays: function () {
        //get month
        var _mm = this._GetMonth();

        //get days
        var _dd;
        switch (_mm) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                _dd = 31;
                break;

            case 4:
            case 6:
            case 9:
            case 11:
                _dd = 30;
                break;

            case 2:
                var _tYear = this._GetCtrlByFF("yyyy");
                var _yy = _tYear ? parseInt(_tYear.value) : _now.getFullYear();
                _dd = (_yy % 4 == 0 && _yy % 100 != 0) || _yy % 400 == 0 ? 29 : 28;
                break;
        };

        //return
        return _dd;
    },

    _GetCtrlByFF: function (_ff) {
        var _ctrl;

        for (var i = 0; i < this.P.ValCtrls.length; i++) {
            if (this.P.ValCtrls[i]._FF == _ff) {
                _ctrl = this.P.ValCtrls[i];
                break;
            }
        };

        return _ctrl;
    },

    _GetDisabledStatus: function () { return (!this.Enabled) || (this.IsShowCheckBox && !this.Checked); },

    _GetFormtAndValues: function (_val, _ff) {
        if (!_ff) _ff = this.Format;
        var _para = new Object();

        var _s = _val.replace(/-/ig, "*");
        _s = _s.replace(new RegExp("/", "ig"), "*");
        _s = _s.replace(new RegExp(" ", "ig"), "*");
        _para.Values = _s.replace(new RegExp(":", "ig"), "*").split("*");

        _ff = !_ff ? this._FF : _ff;
        _s = _ff.replace(/-/ig, "*");
        _s = _s.replace(new RegExp("/", "ig"), "*");
        _s = _s.replace(new RegExp(" ", "ig"), "*");
        _para._FF = _s.replace(new RegExp(":", "ig"), "*").split("*");

        return _para;
    },

    _GetShowDialogHanlder: function (_jc) { return function (event) { _jc._ShowDialog(event); } },

    _ShowDialog: function (_event) {
        //if disabled return
        if (this._GetDisabledStatus() || this.Status == "open") {
            this.Status = "close";
            return;
        }
        this.Status = "open";

        //set focus
        this.P.IsFocused = true;

        //get values
        var _yy = this._GetCtrlByFF("yyyy").value;
        var _mm = this._GetCtrlByFF("MM").value;
        var _dd = this._GetCtrlByFF("dd").value;

        //get objects and parameter
        var _text = _yy + "-" + _mm + "-" + _dd;
        var _val = _yy + "-" + _mm + "-" + _dd;

        //show dialog
        var _cfg = new Object();
        _cfg.WindowName = "win" + this.Container.id;
        _cfg.IsShowHeader = false;
        _cfg.Width = 210;
        _cfg.Height = 170;
        _cfg.PopupMode = "dropdown";
        _cfg.Tag = this;
        _cfg.Event = _event || window.event;
        _cfg.OX = this.P.TB.offsetWidth;
        _cfg.AID = this.AID;

        //show win
        var _win = DialogTool.Show(_cfg);
        var _dialog = new DateTimePickerExDialog(this, _win);
        _dialog.Init(this.Value);
    },


    //============== public methods(inner) ===============
    InitFace: function () {
        //tb
        var _container = this.Container;
        var _tb = this.P.TB = document.createElement("TABLE");
        _tb.setAttribute("border", "0");
        _tb.setAttribute("cellpadding", "0");
        _tb.setAttribute("cellspacing", "0");
        if (this.Width) _tb.style.width = this.Width;
        if (this.Height) _tb.style.height = this.Height + "px";
        _tb.style.margin = "0px";
        _tb.style.padding = "0px";
        _tb.style.borderCollapse = "collapse";
        _tb.style.borderStyle = this.IsShowBorder ? "solid" : "none";
        _tb.style.borderWidth = (this.IsShowBorder ? "1" : "0") + "px";
        _tb.style.display = this.Visible ? "" : "none";
        _tb.className = "dtp_tb sysCtrlBorderColor dropdown_tag";
        _container.appendChild(_tb);

        //tr
        var _tr = _tb.insertRow(-1);

        //checkbox
        var _chk;
        if (this.IsShowCheckBox) {
            _chk = document.createElement("INPUT");
            _chk.setAttribute("type", "checkbox");
            _chk.className = "chk";
            _chk.onclick = this._GetChkClickHandler(this, _chk);
            _chk.onblur = this._GetCtrlBlurHandler(this);
            _chk.onfocus = this._GetCtrlFocusedHandler(this);

            var _td = _tr.insertCell(-1);
            _td.className = "chkTd";
            _td.Ctrl = _chk;
            _td.appendChild(_chk);
            _td.onclick = this._GetCellClickHandler(this);
            _chk.checked = this.Checked;
            _chk.disabled = !this.Enabled;

            this.P.Ctrls.push(_chk);
            this.P.CheckBox = _chk;
        };

        //fill td
        var _fillTd;
        if (this.Align.toLowerCase() == "right") {
            var _td = _tr.insertCell(-1);
            _td.className = "fillTd";
            _td.innerHTML = "&nbsp;";
            _td.onclick = this._GetSpClickHandler(this, _td);
            _fillTd = _td;
        };

        //get parameters
        var _data = this._GetFormtAndValues(this.Value, this.Format);
        var _ff = _data._FF;
        var _values = _data.Values;

        //render tds on value
        var _isDisabled = this._GetDisabledStatus();
        for (var i = 0; i < _ff.length; i++) {
            //get split char
            var _ch;
            if (i < _ff.length - 1) _ch = this.Format.substr(this.Format.indexOf(_ff[i]) + _ff[i].length, 1);

            //create textBox
            var _txt = document.createElement("INPUT");
            _txt.setAttribute("type", "text");
            _txt.setAttribute("value", _values[i]);
            _txt.disabled = _isDisabled;
            _txt._FF = _ff[i];
            _txt.SpChar = _ch;
            _txt.maxLength = parseInt(_ff[i].length);
            _txt.OVal = _values[i];
            _txt.Idx = i;

            _txt.onfocus = this._GetCtrlFocusedHandler(this, _txt);
            _txt.onblur = this._GetCtrlBlurHandler(this, _txt);
            _txt.onkeydown = this._GetTxtKeydownHandler(this, _txt);
            this.P.Ctrls.push(_txt);
            this.P.ValCtrls.push(_txt);
            this.P.TxtCtrls.push(_txt);

            //render td
            var _td = _tr.insertCell(-1);
            if (_ff[i].length == 4) {
                _td.setAttribute("class", "yearTd");
                _td.style.width = "28px";
                _txt.className = "txtYear" + (_isDisabled ? " disabled" : "");
                _txt.Type = "year";
            }
            else {
                _td.className = "txtTd";
                _txt.value = !_values[i] ? "00" : _values[i];
                _txt.SpChar = (_ch && _ch.substring(0, 1) == "<") ? "-" : _ch;
                _txt.className = "txt" + (_isDisabled ? " disabled" : "");
                _txt.Type = "val";
            };
            _td.onclick = this._GetCellClickHandler(this);
            _td.appendChild(_txt);

            //render split td
            if (i < _ff.length - 1) {
                var _td = _tr.insertCell(-1);
                _td.className = "spTd" + (_isDisabled ? " disabled" : "");
                _td.innerHTML = _ch == " " ? "&nbsp;" : _ch;
                _td.Ctrl = _txt;
                _td.onclick = this._GetSpClickHandler(this, _td);
                this.P.Ctrls.push(_td);
                this.P.ValCtrls.push(_td);
            }
        };

        //render fill td
        if (this.Align.toLowerCase() != "right") {
            var _td = _tr.insertCell(-1);
            _td.className = "fillTd";
            _td.innerHTML = "&nbsp;";
            _td.onclick = this._GetSpClickHandler(this, _td);
            _fillTd = _td;
        };

        _fillTd.Ctrl = this.P.Ctrls[0];

        //render btn td
        if (this.IsShowButton) {
            var _td = _tr.insertCell(-1);
            _td.className = "imgTd";
            _td.style.border = "solid 0px";
            _td.style.textAlign = "right";
            _td.Ctrl = this.P.Ctrls[0];
            _td.onclick = this._GetSpClickHandler(this, _td, false);

            var _img = document.createElement("IMG");
            _img.src = this.P.ImgPath + "/" + (_isDisabled ? "dateDisabled.gif" : "date.gif");
            _img.className = "img";
            _img.onclick = this._GetShowDialogHanlder(this);
            _img.Type = "img";
            _td.appendChild(_img);
            this.P.Ctrls.push(_img);
        }
    },

    SetReturnValue: function (_value) {
        if (!_value) return;

        var _arr = _value.split("/");
        if (this._GetCtrlByFF("yyy")) {
            this._GetCtrlByFF("yyyy").value = _arr[0];
        }

        if (this._GetCtrlByFF("MM")) {
            this._GetCtrlByFF("MM").value = _arr[1];
        }

        if (this._GetCtrlByFF("dd")) {
            this._GetCtrlByFF("dd").value = _arr[2];
        }

        this.SetValue(_value, this.Format);
        this._ValueChanged();
        this.SetFocused();
    },


    //============== public methods(outer) ===============
    GetValue: function () {
        //if isn't checkBox then return
        if (this.P.CheckBox && !this.P.CheckBox.checked) return "";

        //get year
        var _rs = "";
        for (var i = 0; i < this.P.ValCtrls.length; i++) {
            var _ctrl = this.P.ValCtrls[i];

            if (_ctrl.type == "text") {
                _rs = _rs + CoreTool.FormatCode(_ctrl.value, _ctrl.Type == "year" ? 4 : 2);
            }
            else {
                _rs += (_ctrl.innerHTML == "&nbsp;" ? " " : _ctrl.innerHTML);
            }
        };

        //return
        return _rs;
    },

    SetValue: function (_val, _ff) {
        //get value and format
        var _data = this._GetFormtAndValues(_val, _ff);
        var _values = _data.Values;
        var _ff = _data._FF;

        //get tr
        for (var i = 0; i < _ff.length; i++) {
            var _ctrl = this._GetCtrlByFF(_ff[i]);
            if (_ctrl && i < _values.length) _ctrl.value = (_val == "" || !_val) ? "00" : _values[i];
        }
        this.Value = this.GetValue();
    },

    GetCheckBoxStatus: function () { return this.IsShowCheckBox && !this.Checked ? false : true; },

    SetCheckBoxValue: function (_val) {
        if (this.IsShowCheckBox) this.P.Ctrls[0].checked = _val;
        this.Checked = _val;

        if (!this._GetDisabledStatus()) {
            this.SetEnabled(_val, "chk");
        }
        else {
            this.SetEnabled(false, "chk");
        }
    },

    SetEnabled: function (_val, _src) {
        //init set
        var _idx = 1;
        if (_src != "chk") {
            this.Container.disabled = !_val;
            this.Enabled = _val;
            _idx = 0;
        }

        //set ctrls
        for (var i = _idx; i < this.P.Ctrls.length; i++) {
            var _ctrl = this.P.Ctrls[i];
            _ctrl.disabled = !_val;

            if (_ctrl.Type != "img") {
                _ctrl.className = _val ? _ctrl.className.replace(/\sdisabled/g, "") : (_ctrl.className) + " disabled";
            }
            else {
                var _isDisabled = this._GetDisabledStatus();
                _ctrl.src = this.P.ImgPath + "/" + (_isDisabled ? "dateDisabled.gif" : "date.gif");
            }
        }
    },

    SetFocused: function (_action) {
        this.P.Ctrls[0].focus();
    }

};