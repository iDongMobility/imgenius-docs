﻿/*---------------------------------------------------------------- 
*  版权所有：上海艾动信息科技有限公司
*  文件名：idong.common.cs
*  文件功能描述：js层通用函数定义文件
//----------------------------------------------------------------*/


//************通用工具类********************

function SysCommon() { }

// 空Guid
SysCommon.GuidEmpty = "00000000-0000-0000-0000-000000000000";

// 简单加密Key
SysCommon.SimpleKey = "ae1911efvva7cvc2rr78aa,,cee";
SysCommon.SimplePre = "!1@2#3$";
        

/// <summary>显示信息提示
///   <para></para>
/// </summary>
/// <param name="_info" type="String">要显示的信息</param>
/// <param name="_callback" type="Function">回调函数</param>
SysCommon.MessageBox = function (_info, _callback) {
    hiAlert(_info, "im企业运营中心", function (_e) {
        if (_callback)
            _callback(_e);
    });
}

/// <summary>操作确认
///   <para></para>
/// </summary>
/// <param name="_info" type="String">要显示的信息</param>
/// <param name="_callback" type="Function">回调函数</param>
SysCommon.ConfirmBox = function (_info, _callback) {
    hiConfirm(_info, 'im企业运营中心', function (_e) {
        if (_callback)
            _callback(_e);
    });
}

/// <summary>根据时间字符串得到毫秒数
///   <para></para>
/// </summary>
/// <param name="_datetimeString" type="String">时间字符串，格式必须为“2010-01-01 10:09:01”或“2010-01-01 10:09”，否则原样返回</param>
/// <return>毫秒数</returen>
SysCommon.GetMilliseconds = function (_datetimeString) {
    // 分割日期和时间
    var splitDatetime = _datetimeString.split(" ");
    if (splitDatetime && splitDatetime.length == 2) {
        var date = splitDatetime[0].split("-");
        var time = splitDatetime[1].split(":");
        if (date && time && date.length == 3) {
            if (time.length == 3) {
                return Date.UTC(date[0], date[1] - 1, date[2], time[0], time[1], time[2], 0);
            }
            else if (time.length == 2) {
                return Date.UTC(date[0], date[1] - 1, date[2], time[0], time[1], 0, 0);
            }
        }
    }
    return _datetimeString;
}

/// <summary>得到相对时间字符串
///   <para></para>
/// </summary>
/// <param name="_datetimeString" type="String">时间字符串，格式必须为“2010-01-01 时间”，否则原样返回</param>
/// <return>相当时间格式字符串</returen>
SysCommon.GetRelativeTime = function (_datetimeString) {
    try {
        // 分割日期和时间
        var splitDatetime = _datetimeString.split(" ");
        if (splitDatetime && splitDatetime.length > 0) {

            // 处理日期（使用相对日期）
            var dateString = splitDatetime[0];
            var date = dateString.split("-");
            if (date && date.length == 3) {
                // 一天毫秒数
                var msOfDay = 86400000;

                // 当前日期
                var nowDate = new Date();
                nowDate.setHours(0, 0, 0, 0);

                // 参数日期
                var parameterDate = new Date();
                parameterDate.setFullYear(date[0], date[1] - 1, date[2]);
                parameterDate.setHours(0, 0, 0, 0);

                // 求出所给日期与当前日期之差                     
                var day = (parameterDate - nowDate) / msOfDay;
                if (day >= -2 && day <= 2) {
                    if (day == 0) {
                        dateString = "今天";
                    }
                    else if (day == 1) {
                        dateString = "明天";
                    }
                    else if (day == 2) {
                        dateString = "后天";
                    }
                    else if (day == -1) {
                        dateString = "昨天";
                    }
                    else if (day == -2) {
                        dateString = "前天";
                    }
                }
            }

            // 处理时间（不显示秒）
            if (splitDatetime.length == 1)
                return dateString;
            else {
                var timeString = splitDatetime[1];
                var time = timeString.split(":");
                if (time && time.length == 3)
                    timeString = time[0] + ":" + time[1];

                return dateString + " " + timeString;
            }
        }
    }
    catch (err) {
    }
    return _datetimeString;
}

/// <summary>得到耗时字符串
///   <para></para>
/// </summary>
/// <param name="_seconds" type="Int">总秒数</param>
/// <return>用天、小时、分钟来描述耗时的字符串</returen>
SysCommon.GetElapsedTime = function (_seconds) {
    try {
        if (_seconds == 0) {
            return "0秒";
        }
        else if (_seconds > 0) {
            var result = "";

            // 天
            var days = parseInt(_seconds / (60 * 60 * 24));
            if (days > 0) {
                result += days + "天";
                _seconds -= days * (60 * 60 * 24);
            }

            // 小时
            var hours = parseInt(_seconds / (60 * 60));
            if (hours > 0) {
                result += hours + "小时";
                _seconds -= hours * (60 * 60)
            }

            // 分钟
            var minutes = parseInt(_seconds / 60);
            _seconds -= minutes * 60;
            if (minutes > 0) {
                result += minutes + "分钟";
            }
            if (_seconds > 0) {
                result += _seconds + "秒";
            }

            return result;
        }
    }
    catch (err) {
    }
    return "未知";
}

//<summary> 将日期时间拆分为日期和时间
//
//</summary>
SysCommon.SpliteDateTime = function (_dateTime) {
    var arr = _dateTime.split(" ");
    var result = new Object();
    result.Date = arr[0];
    result.Time = arr[1].substring(0, 5);
    return result;
}

/// <summary>把字符串转化为浮点数
///   <para></para>
/// </summary>
/// <param name="_value" type="String">待转化的字符串</param>
/// <return>浮点数</returen>
SysCommon.ParseFloat = function (_value) {
    var value = _value.replace(/,/g, "");
    return parseFloat(value);
}

/// <summary>把字符串转化为布尔值
///   <para></para>
/// </summary>
/// <param name="_value" type="String">待转化的字符串</param>
/// <return>布尔值</returen>
SysCommon.ParseBoolean = function (_value) {
    switch (_value.toLowerCase()) {
        case "true":
        case "1":
            return true;
        case "false":
        case "0":
            return false;
        default:
            throw new Error("ParseBoolean:Cannot convert string to boolean.");
    }
}

/// <summary>获取元素的纵坐标
///   <para></para>
/// </summary>
/// <param name="_e" type="Object">html对象</param>
/// <return>整形</returen>
SysCommon.GetTop = function (_e) {
    var offset = _e.offsetTop;
    if (_e.offsetParent != null)
        offset += SysCommon.GetTop(_e.offsetParent);
    return offset;
}

/// <summary>获取元素的横坐标
///   <para></para>
/// </summary>
/// <param name="_e" type="Object">html对象</param>
/// <return>整形</returen>
SysCommon.GetLeft = function (_e) {
    var offset = _e.offsetLeft;
    if (_e.offsetParent != null)
        offset += SysCommon.GetLeft(_e.offsetParent);
    return offset;
}

/// <summary>是否为电话号码
///   <para></para>
/// </summary>
/// <param name="_phoneNumber" type="String">电话号码</param>
/// <return>整形</returen>
SysCommon.IsPhoneNumber = function (_phoneNumber) {
    if (!_phoneNumber)
        return false;
    if (_phoneNumber.length != 11)
        return false;
    var pattern = new RegExp("^([\+][0-9]{1,3}[ \.\-])?([\(]{1}[0-9]{2,6}[\)])?([0-9 \.\-\/]{3,20})((x|ext|extension)[ ]?[0-9]{1,4})?$");
    return pattern.test(_phoneNumber);
}

/// <summary>是否为数值
///   <para></para>
/// </summary>
/// <param name="_number" type="String">数值</param>
/// <return>整形</returen>
SysCommon.IsNumber = function (_number) {
    if (!_number)
        return false;

    var pattern = new RegExp(/^[\-\+]?(([0-9]+)([\.,]([0-9]+))?|([\.,]([0-9]+))?)$/);
    return pattern.test(_number);
}

/// <summary>是否为日期
///   <para></para>
/// </summary>
/// <param name="_date" type="String">日期</param>
/// <return>整形</returen>
SysCommon.IsDate= function (_date) {
    if (!_date)
        return false;

    var pattern = new RegExp(/^\d{4}[\/\-](0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])$/);
    return pattern.test(_date);
}

/// <summary>是否合并显示
///   <para></para>
/// </summary>
/// <param name="_operPanelCondition" type="Array">操作面板条件</param>
/// <return>整形</returen>
SysCommon.IsCombineDisplay = function (_operPanelCondition) {
    if (_operPanelCondition && _operPanelCondition.length > 0) {
        for (var i = 0; i < _operPanelCondition.length; i++) {
            if (_operPanelCondition[i].Items && _operPanelCondition[i].Items.length > 0) {
                for (var j = 0; j < _operPanelCondition[i].Items.length; j++) {
                    if (_operPanelCondition[i].Items[j].Id == "chkCombineDisplay")
                        return SysCommon.ParseBoolean(_operPanelCondition[i].Items[j].Value);
                }
            }
        }
    }
    return false;
}

/// <summary>两个Guid是否相等
///   <para></para>
/// </summary>
SysCommon.IsEqualGuid = function (_left, _right) {
    if (_left && _right)
        return _left.toLowerCase() == _right.toLowerCase();
    else
        return false;
}

/// <summary>是否为Guid
///   <para></para>
/// </summary>
SysCommon.IsGuid = function (_value) {
    if (_value && _value.length == 36) {
        return _.isRegExp(/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/);
    }
    return false;
}

/// <summary>是否为非Empty Guid
///   <para></para>
/// </summary>
SysCommon.IsNotEmptyGuid = function (_value) {
    if (SysCommon.IsGuid(_value)) {
        if (_value == SysCommon.GuidEmpty)
            return false;
        else
            return true;
    }
    else
        return false;
}

/// <summary>得到日期和时间对象
///   <para></para>
/// </summary>
SysCommon.GetDataTimeObj = function (_value) {
    var obj = { Date: "", Time: "" };
    if (_value && _value != null && _value != "") {
        var datetimeArray = _value.split(' ');
        if (datetimeArray.length == 2) {
            obj.Date = datetimeArray[0];
            if (obj.Date) {
                obj.Date = obj.Date.replace("年", "-").replace("月", "-").replace("日", "-");
            }
            obj.Time = datetimeArray[1];
            if (obj.Time) {
                obj.Time = obj.Time.replace("时", ":").replace("小时", ":").replace("分", ":").replace("分钟", ":").replace("秒", ":");
            }
        }
    }
    return obj;
}

/// <summary>格式化字符串是否包含日期
///   <para>默认包含</para>
/// </summary>
SysCommon.IsIncludedDateForFormat = function (_format) {
    return !_format
        || _format.indexOf("yyyy") > -1 || _format.indexOf("MM") > -1 || _format.indexOf("dd") > -1
        || _format.indexOf("年") > -1 || _format.indexOf("月") > -1 || _format.indexOf("日") > -1;
}

/// <summary>格式化字符串是否包含时间
///   <para>默认包含</para>
/// </summary>
SysCommon.IsIncludedTimeForFormat = function (_format) {
    return !_format
    || _format.indexOf("HH") > -1 || _format.indexOf("hh") > -1 || _format.indexOf("mm") > -1 || _format.indexOf("ss") > -1
    || _format.indexOf("时") > -1 || _format.indexOf("小时") > -1 || _format.indexOf("分") > -1 || _format.indexOf("分钟") > -1 || _format.indexOf("秒") > -1;
}

/// <summary>微软时间json格式字符串转化为时间
/// </summary>
/// <param name="_msDateTimeJson" type="String">微软时间json格式字符串</param>
SysCommon.MsDateTimeJsonToDate = function (_msDateTimeJson) {
    return new Date(parseInt(_msDateTimeJson.replace('/Date(', '')));
}

/// <summary>加密
///   <para></para>
/// </summary>
SysCommon.Encrypt = function (_code) {
    if (!_code || _code == "")
        _code = SysCommon.SimplePre;
    else
        _code = SysCommon.SimplePre + _code;

    var code = "";
    for (var i = 0; i < _code.length; i++) {
        var key = i;
        if (i < SysCommon.SimpleKey.length)
            key = SysCommon.SimpleKey.charCodeAt(i);
        var cur = String.fromCharCode(_code.charCodeAt(i) + key);
        code += cur;
    }
    return code;
}

/// <summary>解密
///   <para></para>
/// </summary>
SysCommon.Decrypt = function (_code) {
    if (!_code || _code == "")
        return "";

    var code = "";
    for (var i = 0; i < _code.length; i++) {
        var key = i;
        if (i < SysCommon.SimpleKey.length)
            key = SysCommon.SimpleKey.charCodeAt(i);
        var cur = String.fromCharCode(_code.charCodeAt(i) - key);
        code += cur;
    }
    if (code.indexOf(SysCommon.SimpleKey) == 0) {
        return code.substring(SysCommon.SimpleKey.length);
    } else {
        return _code;
    }
}

/// <summary>保存到当前回话
///   <para></para>
/// </summary>
SysCommon.SaveToSession = function (_key, _value) {
    return StoreData(_key, _value, true);
}

/// <summary>从当前回话获取
///   <para></para>
/// </summary>
SysCommon.GetFromSession = function (_key) {
    return GetaData(_key, true);
}

/// <summary>保存到本地
///   <para></para>
/// </summary>
SysCommon.SaveToLocal = function (_key, _value) {
    return StoreData(_key, _value, false);
}

/// <summary>从本地获取
///   <para></para>
/// </summary>
SysCommon.GetFromLocal = function (_key) {
    return GetaData(_key, false);
}

/// <summary>跳转到作业组详情
/// </summary>
SysCommon.GoDetailsReport = function (_taskGroupID, _controllerName, _actionName, _sequenceID, _activityEntityName, _taskGroupGridData, _taskID, _clickType) {
    SysCommon.SaveDetailsReportParameters(_taskGroupID, _controllerName, _actionName, _sequenceID, _activityEntityName, _taskGroupGridData, _taskID, _clickType);
    var parameters = 'id=' + _taskGroupID + '&controllerName=' + _controllerName + '&actionName=' + _actionName + '&sequenceID=' + (_sequenceID ? _sequenceID : "") + '&activityEntityName=' + (_activityEntityName ? _activityEntityName : "") + '&taskID=' + (_taskID ? _taskID : "") + '&clickType=' + (_clickType ? _clickType : "");
    goUrl("Report", "DetailsReport", parameters);
}

/// <summary>保存作业组详情参数
/// </summary>
SysCommon.SaveDetailsReportParameters = function (_taskGroupID, _controllerName, _actionName, _sequenceID, _activityEntityName, _taskGroupGridData, _taskID, _clickType) {
    var obj = {};
    obj.TaskGroupID = _taskGroupID ? _taskGroupID : "";
    obj.TaskID = _taskID ? _taskID : "";
    obj.ControllerName = _controllerName ? _controllerName : "";
    obj.ActionName = _actionName ? _actionName : "";
    obj.SequenceID = _sequenceID ? _sequenceID : "";
    obj.ActivityEntityName = _activityEntityName ? _activityEntityName : "";
    obj.TaskGroupGridData = _taskGroupGridData ? _taskGroupGridData : [];
    obj.ClickType = _clickType ? _clickType : "TaskGroup";
    var value = JSON2.stringify(obj);
    SysCommon.SaveToSession("TaskDetail_GoDetailsReport", value);
}

/// <summary>得到作业组详情参数
/// </summary>
SysCommon.GetDetailsReportParameters = function () {
    var value = SysCommon.GetFromSession("TaskDetail_GoDetailsReport");
    if (value)
        return JSON2.parse(value);
    else
        return null;
}

/// <summary>格式化数字
/// </summary>
SysCommon.FormatNumber = function (_format, _number) {
    _number = Number(_number);
    var result = _number.toString();
    if (result == "")
        return "";

    try {
        _format = _format.substring(1, _format.length - 1);
        var indexColon = _format.indexOf(":");
        var mode = _format.substr(indexColon + 1, 1);

        switch (mode) {
            case "D":
                result = parseInt(result, 10);
                return result.toString();
                break;
            case "E":
                return _number.toExponential();
                break;
            case "N":
                var pointLength = _format.substr(indexColon + 2);
                if (pointLength == "")
                    pointLength = "2";
                var length = parseInt(pointLength, 10);
                if (length > 0) {
                    result = _number.toFixed(length);
                }

                var indexPoint = result.indexOf(".");
                var preResult = "";
                var sufResult = "";
                if (indexPoint >= 0) {
                    preResult = result.substring(0, indexPoint);
                    sufResult = result.substring(indexPoint + 1);
                } else
                    preResult = result;
                var formatResult = "";
                while (preResult != "") {
                    var i = preResult.length > 3 ? preResult.length - 3 : 0;
                    formatResult = (formatResult != "" ? "," : "") + formatResult;
                    formatResult = preResult.substr(i, 3) + formatResult;
                    preResult = preResult.substring(0, i);

                    if (i == 0)
                        return formatResult + "." + sufResult;
                }
                return "0" + "." + sufResult;
                break;
            default:
                return result;
        }
    } catch (error) {
        return result;
    }
}

SysCommon.BindKeydown = function (_jObj) {
    // 得到需要全屏的区域对象
    var getFullScreenAreaObj = function (_document) {
        if ($('#dgListContainer', _document).length > 0) {
            return $('#dgListContainer', _document);
        }
        else if ($('#workAreaContainer', _document).length > 0) {
            return $('#workAreaContainer', _document);
        }
        else if ($('#ContentContainerWrapper', _document).length > 0) {
            return $('#ContentContainerWrapper', _document);
        }
        else if ($('#homecontent', _document).length > 0) {
            return $('#homecontent', _document);
        }
        return null;
    };

    // 全屏快捷键
    _jObj.keydown(function (event) {
        if ((event.which == 6 || event.which == 102 || event.which == 70) && event.ctrlKey && event.shiftKey) {
            // Ctrl+Shift+F
            var curWindow = window;
            if (window.parent && (window != window.parent) && window.parent.customReportIndex)
                curWindow = window.parent;
            var obj = getFullScreenAreaObj(curWindow.document);
            if (obj) {
                obj.toggleClass('imfullscreen');
                $(curWindow).trigger('resize');
            }
        }
        else if (event.which == 27) {
            // Esc
            var curWindow = window;
            if (window.parent && (window != window.parent) && window.parent.customReportIndex)
                curWindow = window.parent;
            var obj = getFullScreenAreaObj(curWindow.document);
            if (obj && obj.hasClass("imfullscreen")) {
                obj.removeClass('imfullscreen');
                $(curWindow).trigger('resize');
            }
        }
    });
}



// 内置对象功能扩展

/// <summary>字符串格式化
/// 两种调用方式
/// var template1 = "我是{0}，今年{1}了";
/// var template2 = "我是{name}，今年{age}了";
/// var result1 = template1.format("loogn", 22);
/// var result2 = template2.format({ name: "loogn", age: 22 });
/// 两个结果都是"我是loogn，今年22了"
/// </summary>
String.prototype.format = function (args) {
    var result = this;
    if (arguments.length > 0) {
        if (arguments.length == 1 && typeof (args) == "object") {
            for (var key in args) {
                if (args[key] != undefined) {
                    var reg = new RegExp("({" + key + "})", "g");
                    result = result.replace(reg, args[key]);
                }
            }
        }
        else {
            for (var i = 0; i < arguments.length; i++) {
                if (arguments[i] != undefined) {
                    var reg = new RegExp("({)" + i + "(})", "g");
                    result = result.replace(reg, arguments[i]);
                }
            }
        }
    }
    return result;
}



var processSessionEnd = null;

$(function () {

    $('div[region="north"]').css({ "height": "102px", "overflow": "hidden"    });

    //设置首页
    $('#sethomepage').bind('click', function (event) {
        event.preventDefault();
        SysTool.ShowMessage();
        try {
            var action = IDONGA;            
            var homePage = action + '§' + IDONGC;
            $.post('/Manage/SetHomePage', { _homePage: homePage }, function (_result) {
                SysTool.HideMessage();
                if (_result.IsSuccess)
                    SysCommon.MessageBox('设置首页成功。');
                else
                    SysCommon.MessageBox('设置首页失败，原因为：' + _result.Msg);
            });
        }
        catch (_e) {
            SysTool.HideMessage();
            SysCommon.MessageBox('设置首页失败，原因为：' + _e.message);
        }
    });

    $('#homePage').bind('click', function () {
        goUrl("Home", "Home");
    });

    $('#planCreatePage').bind('click', function () {
        goUrl("TaskGroup", "Index");
    });

    $('#taskJobPage').bind('click', function () {
        goUrl("TaskJob", "Index");
    });

    $('#auditsPage').bind('click', function () {
        goUrl("Audits", "Auditing");
    });

    $('#reportPage').bind('click', function () {
        goUrl("CustomReport", "Index");
    });

    $('#kpiPage').bind('click', function () {
        goUrl("KPI", "Index");
    });

    $('#operaLogPage').bind('click', function () {
        goUrl("OperaLog", "Index");
    });

    $('#ekbPage').bind('click', function () {
        goUrl("Article", "SummaryView");
    });

    $('#managePage').bind('click', function () {
        goUrl("Manage", "Index");
    });

    $('#helpPage').unbind('click').bind('click', function () {
        $.post('/Home/GetRebrandInfo', null, function (_data) {
            if (_data) {
                if (_data.IsShowHelp) {
                    window.open("/imEOC_Userguide/index.htm", "Help");
                }
            }
            else
                window.open("/imEOC_Userguide/index.htm", "Help");
        });
    });

    // 初始化关于对话框
    if ($('#aboutPage').length > 0) {
        InitAbuotDialog()
        $('#aboutPage').unbind('click').bind('click', function (event) {
            event.preventDefault();

            $.post('/Home/GetRebrandInfo', null, function (_data) {
                if (_data) {
                    $('#CompanyName').html(_data.CompanyName);
                    $('#CompanyURL').html(_data.URL);
                    $('#CompanyURL').attr("href", _data.URL);
                    if (_data.CopyRight) {
                        $('#CopyRightCaption').show();
                        $('#CopyRight').html(_data.CopyRight);
                    }
                    else
                        $('#CopyRightCaption').hide();
                }

                $("#AbuotDialog .dialog-content").css("display", "");
                $("#AbuotDialog").css("display", "");
                $('#AbuotDialog').dialog('open');
            });
        });
    }

    SysCommon.BindKeydown($(document));
})

//初始关于对话框
function InitAbuotDialog() {
    $('#AbuotDialog').dialog({
        modal: true,
        resizable: false,
        hide: 'slide',
        closed: true
    });
    $('#AbuotDialog').dialog('close');   
}

/// <summary>跳转到另外一个页面
///   <para></para>
/// </summary>
/// <param name="_controllerName" type="String">控制器名</param>
/// <param name="_actionName" type="String">动作名</param>
/// <param name="_parameters" type="String">参数</param>
function goUrl(_controllerName, _actionName, _parameters) {
    if (!IsNotNull(_controllerName) || !IsNotNull(_actionName)) {
        return;
    }

    var url = '/' + _controllerName + '/' + _actionName;
    if (IsNotNull(_parameters)) {
        url += "?" + _parameters;
    }

    if (window.parent == window)
        window.location.href = url;
    else window.parent.location.href = url;
}

/**
* 写Cookie值
* 
* 参数：cookieName，类型为字符串，Cookie名字
* 参数：cookieValue，类型为字符串，Cookie值
* 参数：hasPath，类型为布尔，是否有路径
* 返回：写入是否成功
*/
function WriteCookie(cookieName, cookieValue, hasPath) {
    var userID = GetUserID();
    if (IsNotNull(userID)) {
        var newName = 'idong_' + userID + '_' + cookieName;
        var path = '/';
        if (hasPath) {
            var action = IDONGA;
            path = '/' + IDONGC + "/" + action;
        }

        $.cookie(newName, cookieValue, { expires: 7,path: path, secure: false });
        return true;
    }
    else
        return false;   
}

/**
* 得到Cookie值
* 
* 参数：cookieName，类型为字符串，Cookie名字
* 返回：Cookie值
*/
function GetCookie(cookieName) {
    var userID = GetUserID();
    if (IsNotNull(userID)) {
        var newName = 'idong_' + userID + '_' + cookieName;
        return $.cookie(newName);
    }
    else
        return "";
}

/**
* 存储数据
*/
function StoreData(_key, _value, _isSession) {
    var storage = GetWebStorge(_isSession);
    if (storage == null)
        return;
    var userID = GetUserID();
    if (IsNotNull(userID)) {
        var _newKey = 'idong_' + userID + '_' + _key;
        storage.setItem(_newKey, _value);
        return true;
    }
    else
        return false
}

/**
* 得到数据
*/
function GetaData(_key, _isSession) {
    var storage = GetWebStorge(_isSession);
    if (storage == null)
        return;
    var userID = GetUserID();
    if (IsNotNull(userID)) {
        var _newKey = 'idong_' + userID + '_' + _key;
        return storage.getItem(_newKey);
    }
    else
        return "";
}

/// <summary>清除Storge数据
///   <para></para>
/// </summary>
/// <param name="_isSession" type="Boolean">是否是会话Storge</param>
function ClearStorgeData(_isSession) {
    var storage = GetWebStorge(_isSession);
    if (storage == null)
        return;
    storage.clear();
}

/**
* 得到Web Storge对象
*/
function GetWebStorge(_isSession) {
    var storage = null;
    if (_isSession)
        storage = window.sessionStorage;
    else
        storage = window.localStorage;

    if (IsNotNull(storage)) {
        return storage;
    }
    else {
        SysCommon.MessageBox("浏览器不支持Web Storage");
        return null;
    }
}

/**
* 得到当前登录用户ID
* 
* 返回：用户ID字符串
*/
function GetUserID() {
    return $.cookie('idong_userid');
}

/**
* 判断指定值是否不为空
* 
* 参数：value,类型为字符串
* 返回：字符串有值，返回true，否则返回false
*/
function IsNotNull(value) {
    if (typeof(value) != undefined && value != null && value != "")
        return true;
    else
        return false;
}

/**
* 得到当前时间字符串
* 
* 参数：dateTimeType,类型为字符串，可选值为date或dateTime
* 返回：时间字符串
*/
function GetDateTimeString(now, dateTimeType) {

    if (!Commons.IsNotNull(now)) {
        now = new Date();
    }
    var year = now.getFullYear();
    var month = now.getMonth();
    var date = now.getDate();
    var day = now.getDay();
    var hour = now.getHours();
    var minu = now.getMinutes();
    var sec = now.getSeconds();
    month = month + 1;
    var time = "";
    switch (dateTimeType) {
        case "date":
            time = year + "-" + month + "-" + date;
            break;
        case "dateTime":
            time = year + "-" + month + "-" + date + " " + hour + ":" + minu + ":" + sec;
            break;
        case "week":
            var txtDate = date-6;
            time = year + "-"+month+"-"+txtDate;
            break;
    }    
    return time;
}

/**
* 根据时间得到毫秒数
* 
* 参数Value：类型为字符串，表示时间，格式必须为2010-01-01
* 返回：毫秒数
*/
function DateParser(value) {
    var splitDate = value.split("-");
    if (splitDate) {
        var utcMilliseconds = Date.UTC(splitDate[0], splitDate[1] - 1, splitDate[2], 0, 0, 0, 0);
        return utcMilliseconds;
    }
    return value;
}

/**
* 当前时间减去特定天数
* 
* 参数value：类型为字符串，表示时间，格式必须为2010-01-01
* 参数day：类型为整数，表示要减去的天数
* 返回：毫秒数
*/
function DateParserDay(value, day) {
    var ms = DateParser(value);
    var newMs = ms - day * 24 * 60 * 60*1000;
    var newDate = new Date(newMs);
    return GetDateTimeString(newDate, "date");
}

//为Grid指定行或列添加样式
function onRowDataBound(e) {
    //debugger;
    var grid = $(this).data('tGrid');
    var tRow = e.row;
    var dataItem = e.dataItem;
    if (dataItem.colorCol != null && $.trim(dataItem.colorCol) != "") {
        //$(tRow).attr("style", "background-color:#" + dataItem.colorCol);
        var col = $(tRow).find("td:gt(0)");
        col.attr("style", "background-color:#" + dataItem.colorCol);
    }
}

//Ajax请求刷新Grid
function AjaxRefreshGrid() {
    var grid = $('#Grid').data('tGrid');
    if (grid != null) {
        grid.pageTo(1);
    }
      
}

function BindDateTimeEvent() {
    $('.calpick').remove();
    $(".datetime").datepicker({ picker: "<input class='calpick' type='button' style='margin-left: 5px; margin-bottom: 4px;'/>" });
}

/**
* 根据全时间字符串得到毫秒数
* 
* value：字符串，表示时间，格式必须为2010-01-01 10:09:01
* 返回：毫秒数
*/
function DatetimeParser(value) {
    var splitDatetime = value.split(" ");
    if (splitDatetime && splitDatetime.length == 2) {
        var date = splitDatetime[0].split("-");
        var time = splitDatetime[1].split(":");
        if (date && time && date.length == 3) {
            if (time.length == 3) {
                var utcMilliseconds = Date.UTC(date[0], date[1] - 1, date[2], time[0], time[1], time[2], 0);
                return utcMilliseconds;
            }
            else if (time.length == 2) {
                var utcMilliseconds = Date.UTC(date[0], date[1] - 1, date[2], time[0], time[1], 0, 0);
                return utcMilliseconds;
            }
        }
    }
    return value;
}

/**
* 根据全时间字符串得到毫秒数
* 
* value：字符串，表示时间，格式必须为2010年01月01日 10:09:01
* 返回：毫秒数
*/
function DatetimeParser2(value) {
    value = value.replace("年", "-");
    value = value.replace("月", "-");
    value = value.replace("日", "");
    return DatetimeParser(value);
}

/**
* 布尔字符串转化为布尔值
* 
* value：布尔字符串
* 返回：布尔值
*/
function ToBoolean(value) {
    switch (value.toLowerCase()) {
        case "true":
            return true;
        case "false":
            return false;
        default:
            throw new Error("ToBoolean: Cannot convert string to boolean.");
    }
}

/// <summary>比较两个字符串是否相等
///   <para></para>
/// </summary>
/// <param name="_firstStr" type="String">第一个字符串</param>
/// <param name="_secondStr" type="String">第二个字符串</param>
/// <param name="_ignoreCase" type="Boolean">是否忽略大小写，如果不传递此参数，表示true</param>
/// <return>返回说明</returen>
function IsEqual(_firstStr, _secondStr, _ignoreCase) {
    if (typeof (_ignoreCase) == "undefined" || _ignoreCase) {
        if (_firstStr && _firstStr != null)
            _firstStr = _firstStr.toLowerCase();
        if (_secondStr && _firstStr != null)
            _secondStr = _secondStr.toLowerCase();
    }
    return (_firstStr == _secondStr);
}

/// <summary>
///  十进制颜色数据转换为十六进制颜色
/// </summary>
/// <param name="_parameter" type="String">十进制颜色数据</param>
/// <return>返回说明</returen>
function DecimalToHexString(number) {
    if (number < 0) {
        number = 0xFFFFFFFF + number + 1;
    }
    var temp = number.toString(16).toUpperCase()
    var ret = "";
    if (temp.length >= 7) {
        for (var i = 2; i < temp.length; i++) {
            if (temp.length > i) {
                ret = ret + temp.charAt(i);
            }
        }
    }
    else {
        ret = temp;
    }
    return ret;
}

//根据窗口缩放大小
function DivResize(divContent,otherHeight) {
    function ContentResize() {
        var _divContent = $(divContent);
        if (_divContent == null || _divContent == "" || _divContent == undefined) {
            return false;
        }
        var fullArea = _divContent.parents('.imfullscreen');
        if (fullArea.length > 0) {
            var height = fullArea.height() - otherHeight + 46;
            height = Math.max(height, 0);
            _divContent.height(height);
        }
        else {
            var eocheadHeight = $('.eochead')[0].offsetHeight;
            var height = document.documentElement.clientHeight - (eocheadHeight + otherHeight);
            height = Math.max(height, 0);
            _divContent.height(height);
        }        
    }
    $(window).wresize(ContentResize);
    ContentResize();
}

$(document).ajaxError(function (e, xhr, settings, exception) {
    if (xhr.status == 308) {
        if (processSessionEnd != null) {
            processSessionEnd();
        }
        goUrl("Account", "Logon");
        return false;
    }
});


/*------------------------------------------------------------------ 
*  类功能描述：处理公共使用的基础静态API
//----------------------------------------------------------------*/
var Commons = {

    //初始化对话框
    InintDialogElment: function (action, dialogId, dialogTitle, dialogIcon, _onSave, _onMove, _onClose) {

        var butArry = [{
            text: '保存',
            iconCls: 'icon-save',
            handler: function () {
                if (_onSave) {
                    if (_onSave(true) == false) {
                        return false;
                    }
                    else {
                        $(dialogId).dialog('close');
                    }
                }
            }
        }, {
            text: '取消',
            iconCls: 'icon-cancel',
            handler: function () {
                if (_onSave)
                    _onSave(false);
                $(dialogId).dialog('close');
            }
        }];
        if (action == "detail") {
            butArry = null;
        }
        $(dialogId).dialog({
            modal: true,
            resizable: false,
            hide: 'slide',
            title: dialogTitle,
            iconCls: dialogIcon,
            closed: true,
            buttons: butArry,
            onMove: _onMove,
            onClose: _onClose
        });
    },
    //根据对话框ID打开对话框
    OpenDialog: function (dialogId, caption) {
        $(dialogId).css("display", "");
        $(dialogId + " .dialog-content").css("display", "");
        $(dialogId).dialog('setTitle', caption);
        $(dialogId).dialog({ position: ["50"] });
        $(dialogId).dialog('open');
    },
    //验证值是否为空
    IsNotNull: function (value) {
        if (typeof (value) != undefined && value != null && value != "")
            return true;
        else
            return false;
    },
    //把Json日期对象转换成普通日期时间字符串
    ChangeDateFormat: function (cellval) {
        var date = new Date(parseInt(cellval.replace("/Date(", "").replace(")/", ""), 10));
        return now = $.format.date(date, 'yyyy-MM-dd HH:mm:ss')
    },
    //获取当前系统时间
    GetSystemDateTime: function (_format) {
        var date = new Date();
        return now = $.format.date(date, _format);
    },
    /// </summary>保留两位小数,功能：将浮点数四舍五入，取小数点后2位 
    ///   <para>数值</para>
    /// </summary>
    ToDecimal: function (_number) {
        var f = parseFloat(_number);
        if (isNaN(f)) {
            return;
        }
        f = Math.round(_number * 100) / 100;
        return f;
    },
    NewGuid: function () {
        var guid = "";
        for (var i = 1; i <= 32; i++) {
            var n = Math.floor(Math.random() * 16.0).toString(16);
            guid += n;
            if ((i == 8) || (i == 12) || (i == 16) || (i == 20))
                guid += "-";
        }
        return guid;
    }
}